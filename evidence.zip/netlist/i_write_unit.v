// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.1 (win64) Build 2902540 Wed May 27 19:54:49 MDT 2020
// Date        : Thu Sep 24 12:47:58 2026
// Host        : DESKTOP-9T3TD2K running 64-bit major release  (build 9200)
// Command     : write_verilog -cell i_cheshire_soc/gen_llc.i_llc/i_axi_llc_top_raw/i_write_unit -mode funcsim
//               -include_xilinx_libs
//               D:/project/ara/hardware/fpga/ara_dsa_vcu118/software/axi_netlists/20260924_124446_iul23phx/i_write_unit.v
// Design      : axi_llc_write_unit
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xcvu9p-flga2104-2L-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* \AxiCfg[AddrWidthFull]  = "48" *) (* \AxiCfg[DataWidthFull]  = "64" *) (* \AxiCfg[SlvPortIdWidth]  = "4" *) 
(* \Cfg[BlockOffsetLength]  = "3" *) (* \Cfg[BlockSize]  = "64" *) (* \Cfg[ByteOffsetLength]  = "3" *) 
(* \Cfg[IndexLength]  = "8" *) (* \Cfg[NumBlocks]  = "8" *) (* \Cfg[NumLines]  = "256" *) 
(* \Cfg[SPMLength]  = "131072" *) (* \Cfg[SetAssociativity]  = "8" *) (* \Cfg[TagLength]  = "34" *) 
(* NotValidForBitStream *)
module axi_llc_write_unit
   (clk_i,
    rst_ni,
    test_i,
    \desc_i[a_x_id] ,
    \desc_i[a_x_addr] ,
    \desc_i[a_x_len] ,
    \desc_i[a_x_size] ,
    \desc_i[a_x_burst] ,
    \desc_i[a_x_lock] ,
    \desc_i[a_x_cache] ,
    \desc_i[a_x_prot] ,
    \desc_i[x_resp] ,
    \desc_i[x_last] ,
    \desc_i[spm] ,
    \desc_i[rw] ,
    \desc_i[way_ind] ,
    \desc_i[evict] ,
    \desc_i[evict_tag] ,
    \desc_i[refill] ,
    \desc_i[flush] ,
    desc_valid_i,
    desc_ready_o,
    \w_chan_slv_i[data] ,
    \w_chan_slv_i[strb] ,
    \w_chan_slv_i[last] ,
    \w_chan_slv_i[user] ,
    w_chan_valid_i,
    w_chan_ready_o,
    \b_chan_slv_o[id] ,
    \b_chan_slv_o[resp] ,
    \b_chan_slv_o[user] ,
    b_chan_valid_o,
    b_chan_ready_i,
    \way_inp_o[cache_unit] ,
    \way_inp_o[way_ind] ,
    \way_inp_o[line_addr] ,
    \way_inp_o[blk_offset] ,
    \way_inp_o[we] ,
    \way_inp_o[data] ,
    \way_inp_o[strb] ,
    way_inp_valid_o,
    way_inp_ready_i,
    \w_unlock_o[index] ,
    \w_unlock_o[way_ind] ,
    w_unlock_req_o,
    w_unlock_gnt_i);
  input clk_i;
  input rst_ni;
  input test_i;
  input [3:0]\desc_i[a_x_id] ;
  input [47:0]\desc_i[a_x_addr] ;
  input [7:0]\desc_i[a_x_len] ;
  input [2:0]\desc_i[a_x_size] ;
  input [1:0]\desc_i[a_x_burst] ;
  input \desc_i[a_x_lock] ;
  input [3:0]\desc_i[a_x_cache] ;
  input [2:0]\desc_i[a_x_prot] ;
  input [1:0]\desc_i[x_resp] ;
  input \desc_i[x_last] ;
  input \desc_i[spm] ;
  input \desc_i[rw] ;
  input [7:0]\desc_i[way_ind] ;
  input \desc_i[evict] ;
  input [33:0]\desc_i[evict_tag] ;
  input \desc_i[refill] ;
  input \desc_i[flush] ;
  input desc_valid_i;
  output desc_ready_o;
  input [63:0]\w_chan_slv_i[data] ;
  input [7:0]\w_chan_slv_i[strb] ;
  input \w_chan_slv_i[last] ;
  input [1:0]\w_chan_slv_i[user] ;
  input w_chan_valid_i;
  output w_chan_ready_o;
  output [3:0]\b_chan_slv_o[id] ;
  output [1:0]\b_chan_slv_o[resp] ;
  output [1:0]\b_chan_slv_o[user] ;
  output b_chan_valid_o;
  input b_chan_ready_i;
  output [1:0]\way_inp_o[cache_unit] ;
  output [7:0]\way_inp_o[way_ind] ;
  output [7:0]\way_inp_o[line_addr] ;
  output [2:0]\way_inp_o[blk_offset] ;
  output \way_inp_o[we] ;
  output [63:0]\way_inp_o[data] ;
  output [7:0]\way_inp_o[strb] ;
  output way_inp_valid_o;
  input way_inp_ready_i;
  output [7:0]\w_unlock_o[index] ;
  output [7:0]\w_unlock_o[way_ind] ;
  output w_unlock_req_o;
  input w_unlock_gnt_i;

  wire [13:0]addr;
  wire b_chan_ready_i;
  wire [3:0]\b_chan_slv_o[id] ;
  wire [1:0]\b_chan_slv_o[resp] ;
  wire b_chan_valid_o;
  wire b_ready;
  wire b_valid8_out;
  wire busy_d13_in;
  wire busy_q;
  wire clk_i;
  wire [13:0]\desc_d[a_x_addr] ;
  wire [7:0]\desc_d[a_x_len] ;
  wire [47:0]\desc_i[a_x_addr] ;
  wire [1:0]\desc_i[a_x_burst] ;
  wire [3:0]\desc_i[a_x_id] ;
  wire [7:0]\desc_i[a_x_len] ;
  wire [2:0]\desc_i[a_x_size] ;
  wire [7:0]\desc_i[way_ind] ;
  wire \desc_i[x_last] ;
  wire [1:0]\desc_i[x_resp] ;
  wire desc_q;
  wire \desc_q[a_x_addr][13]_i_1_n_0 ;
  wire \desc_q[a_x_addr][13]_i_4_n_0 ;
  wire \desc_q[a_x_addr][13]_i_5_n_0 ;
  wire \desc_q[a_x_addr][13]_i_6_n_0 ;
  wire \desc_q[a_x_addr][2]_i_2_n_0 ;
  wire \desc_q[a_x_addr][4]_i_2_n_0 ;
  wire \desc_q[a_x_addr][6]_i_2_n_0 ;
  wire \desc_q[a_x_addr][7]_i_10_n_0 ;
  wire \desc_q[a_x_addr][7]_i_3_n_0 ;
  wire \desc_q[a_x_addr][7]_i_4_n_0 ;
  wire \desc_q[a_x_addr][7]_i_5_n_0 ;
  wire \desc_q[a_x_addr][7]_i_6_n_0 ;
  wire \desc_q[a_x_addr][7]_i_7_n_0 ;
  wire \desc_q[a_x_addr][7]_i_8_n_0 ;
  wire \desc_q[a_x_addr][7]_i_9_n_0 ;
  wire \desc_q[a_x_len][3]_i_2_n_0 ;
  wire \desc_q[a_x_len][4]_i_2_n_0 ;
  wire \desc_q[a_x_len][5]_i_2_n_0 ;
  wire \desc_q[a_x_len][6]_i_2_n_0 ;
  wire \desc_q[a_x_len][7]_i_1_n_0 ;
  wire \desc_q[way_ind][7]_i_3_n_0 ;
  wire \desc_q_reg[a_x_addr][7]_i_2_n_0 ;
  wire \desc_q_reg[a_x_addr_n_0_][0] ;
  wire \desc_q_reg[a_x_addr_n_0_][1] ;
  wire \desc_q_reg[a_x_addr_n_0_][2] ;
  wire [1:0]\desc_q_reg[a_x_burst] ;
  wire \desc_q_reg[a_x_id_n_0_][0] ;
  wire \desc_q_reg[a_x_id_n_0_][1] ;
  wire \desc_q_reg[a_x_id_n_0_][2] ;
  wire \desc_q_reg[a_x_id_n_0_][3] ;
  wire [7:0]\desc_q_reg[a_x_len] ;
  wire \desc_q_reg[x_last]__0 ;
  wire \desc_q_reg[x_resp_n_0_][1] ;
  wire desc_ready_o;
  wire desc_ready_o_INST_0_i_1_n_0;
  wire desc_ready_o_INST_0_i_2_n_0;
  wire desc_ready_o_INST_0_i_3_n_0;
  wire desc_valid_i;
  wire rst_ni;
  wire [2:0]size;
  wire w_chan_ready_o;
  wire [63:0]\w_chan_slv_i[data] ;
  wire [7:0]\w_chan_slv_i[strb] ;
  wire w_chan_valid_i;
  wire w_ready5_out;
  wire w_unlock_gnt_i;
  wire w_unlock_req_o;
  wire w_unlock_req_o_INST_0_i_1_n_0;
  wire w_unlock_req_o_INST_0_i_2_n_0;
  wire w_valid;
  wire [2:0]\way_inp_o[blk_offset] ;
  wire [63:0]\way_inp_o[data] ;
  wire [7:0]\way_inp_o[line_addr] ;
  wire [7:0]\way_inp_o[strb] ;
  wire [7:0]\way_inp_o[way_ind] ;
  wire way_inp_ready_i;
  wire way_inp_valid_o;
  wire [7:0]\NLW_desc_q_reg[a_x_addr][13]_i_3_CO_UNCONNECTED ;
  wire [7:6]\NLW_desc_q_reg[a_x_addr][13]_i_3_DI_UNCONNECTED ;
  wire [7:6]\NLW_desc_q_reg[a_x_addr][13]_i_3_O_UNCONNECTED ;
  wire [7:6]\NLW_desc_q_reg[a_x_addr][13]_i_3_S_UNCONNECTED ;
  wire [6:0]\NLW_desc_q_reg[a_x_addr][7]_i_2_CO_UNCONNECTED ;
  wire [0:0]\NLW_i_spill_register_b_data_i[resp]_UNCONNECTED ;
  wire [1:0]\NLW_i_spill_register_b_data_i[user]_UNCONNECTED ;
  wire [0:0]\NLW_i_spill_register_b_data_o[resp]_UNCONNECTED ;
  wire [1:0]\NLW_i_spill_register_b_data_o[user]_UNCONNECTED ;
  wire \NLW_i_w_stream_fifo_data_i[last]_UNCONNECTED ;
  wire \NLW_i_w_stream_fifo_data_o[last]_UNCONNECTED ;
  wire NLW_i_w_stream_fifo_flush_i_UNCONNECTED;
  wire NLW_i_w_stream_fifo_testmode_i_UNCONNECTED;
  wire [1:0]\NLW_i_w_stream_fifo_data_i[user]_UNCONNECTED ;
  wire [1:0]\NLW_i_w_stream_fifo_data_o[user]_UNCONNECTED ;
  wire [2:0]NLW_i_w_stream_fifo_usage_o_UNCONNECTED;

  LUT4 #(
    .INIT(16'h4F44)) 
    busy_q_i_1
       (.I0(busy_q),
        .I1(desc_valid_i),
        .I2(w_unlock_req_o_INST_0_i_2_n_0),
        .I3(w_unlock_req_o_INST_0_i_1_n_0),
        .O(busy_d13_in));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    busy_q_reg
       (.C(clk_i),
        .CE(busy_d13_in),
        .CLR(rst_ni),
        .D(desc_valid_i),
        .Q(busy_q));
  LUT6 #(
    .INIT(64'hFFFF020002000200)) 
    \desc_q[a_x_addr][0]_i_1 
       (.I0(\desc_q[a_x_addr][2]_i_2_n_0 ),
        .I1(size[1]),
        .I2(size[0]),
        .I3(addr[0]),
        .I4(\desc_i[a_x_addr] [0]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][10]_i_1 
       (.I0(addr[10]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [10]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [10]));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][11]_i_1 
       (.I0(addr[11]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [11]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [11]));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][12]_i_1 
       (.I0(addr[12]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [12]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [12]));
  LUT5 #(
    .INIT(32'hEAEAEAAA)) 
    \desc_q[a_x_addr][13]_i_1 
       (.I0(desc_q),
        .I1(w_unlock_req_o_INST_0_i_2_n_0),
        .I2(w_unlock_req_o_INST_0_i_1_n_0),
        .I3(\desc_q_reg[a_x_burst] [1]),
        .I4(\desc_q_reg[a_x_burst] [0]),
        .O(\desc_q[a_x_addr][13]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][13]_i_2 
       (.I0(addr[13]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [13]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [13]));
  LUT4 #(
    .INIT(16'hFE00)) 
    \desc_q[a_x_addr][13]_i_4 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(desc_ready_o_INST_0_i_1_n_0),
        .I2(\desc_q_reg[a_x_len] [7]),
        .I3(busy_q),
        .O(\desc_q[a_x_addr][13]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000002FFFFFFFF)) 
    \desc_q[a_x_addr][13]_i_5 
       (.I0(\desc_q[a_x_addr][13]_i_6_n_0 ),
        .I1(\desc_q_reg[a_x_len] [7]),
        .I2(\desc_q_reg[a_x_len] [6]),
        .I3(\desc_q_reg[a_x_len] [5]),
        .I4(\desc_q_reg[a_x_len] [4]),
        .I5(busy_q),
        .O(\desc_q[a_x_addr][13]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \desc_q[a_x_addr][13]_i_6 
       (.I0(\desc_q_reg[a_x_len] [1]),
        .I1(\desc_q_reg[a_x_len] [0]),
        .I2(\desc_q_reg[a_x_len] [3]),
        .I3(\desc_q_reg[a_x_len] [2]),
        .O(\desc_q[a_x_addr][13]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF002000200020)) 
    \desc_q[a_x_addr][1]_i_1 
       (.I0(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I1(size[2]),
        .I2(addr[1]),
        .I3(size[1]),
        .I4(\desc_i[a_x_addr] [1]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [1]));
  LUT6 #(
    .INIT(64'hFFFF2A002A002A00)) 
    \desc_q[a_x_addr][2]_i_1 
       (.I0(\desc_q[a_x_addr][2]_i_2_n_0 ),
        .I1(size[1]),
        .I2(size[0]),
        .I3(addr[2]),
        .I4(\desc_i[a_x_addr] [2]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [2]));
  LUT5 #(
    .INIT(32'h0000AAA8)) 
    \desc_q[a_x_addr][2]_i_2 
       (.I0(busy_q),
        .I1(\desc_q_reg[a_x_len] [7]),
        .I2(desc_ready_o_INST_0_i_1_n_0),
        .I3(\desc_q_reg[a_x_len] [0]),
        .I4(size[2]),
        .O(\desc_q[a_x_addr][2]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFF080808)) 
    \desc_q[a_x_addr][3]_i_1 
       (.I0(addr[3]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(size[2]),
        .I3(\desc_i[a_x_addr] [3]),
        .I4(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [3]));
  LUT6 #(
    .INIT(64'hF8888888FF888888)) 
    \desc_q[a_x_addr][4]_i_1 
       (.I0(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .I1(\desc_i[a_x_addr] [4]),
        .I2(\desc_q[a_x_addr][4]_i_2_n_0 ),
        .I3(addr[4]),
        .I4(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I5(size[2]),
        .O(\desc_d[a_x_addr] [4]));
  LUT2 #(
    .INIT(4'h1)) 
    \desc_q[a_x_addr][4]_i_2 
       (.I0(size[0]),
        .I1(size[1]),
        .O(\desc_q[a_x_addr][4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h8F888888FF888888)) 
    \desc_q[a_x_addr][5]_i_1 
       (.I0(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .I1(\desc_i[a_x_addr] [5]),
        .I2(size[1]),
        .I3(addr[5]),
        .I4(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I5(size[2]),
        .O(\desc_d[a_x_addr] [5]));
  LUT6 #(
    .INIT(64'hF8888888FF888888)) 
    \desc_q[a_x_addr][6]_i_1 
       (.I0(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .I1(\desc_i[a_x_addr] [6]),
        .I2(\desc_q[a_x_addr][6]_i_2_n_0 ),
        .I3(addr[6]),
        .I4(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I5(size[2]),
        .O(\desc_d[a_x_addr] [6]));
  LUT2 #(
    .INIT(4'h7)) 
    \desc_q[a_x_addr][6]_i_2 
       (.I0(size[0]),
        .I1(size[1]),
        .O(\desc_q[a_x_addr][6]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][7]_i_1 
       (.I0(addr[7]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [7]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [7]));
  LUT4 #(
    .INIT(16'hAAA9)) 
    \desc_q[a_x_addr][7]_i_10 
       (.I0(\desc_q_reg[a_x_addr_n_0_][0] ),
        .I1(size[2]),
        .I2(size[0]),
        .I3(size[1]),
        .O(\desc_q[a_x_addr][7]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h6AAA)) 
    \desc_q[a_x_addr][7]_i_3 
       (.I0(\way_inp_o[line_addr] [1]),
        .I1(size[0]),
        .I2(size[1]),
        .I3(size[2]),
        .O(\desc_q[a_x_addr][7]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h9AAA)) 
    \desc_q[a_x_addr][7]_i_4 
       (.I0(\way_inp_o[line_addr] [0]),
        .I1(size[0]),
        .I2(size[1]),
        .I3(size[2]),
        .O(\desc_q[a_x_addr][7]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hAA6A)) 
    \desc_q[a_x_addr][7]_i_5 
       (.I0(\way_inp_o[blk_offset] [2]),
        .I1(size[0]),
        .I2(size[2]),
        .I3(size[1]),
        .O(\desc_q[a_x_addr][7]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hAAA6)) 
    \desc_q[a_x_addr][7]_i_6 
       (.I0(\way_inp_o[blk_offset] [1]),
        .I1(size[2]),
        .I2(size[0]),
        .I3(size[1]),
        .O(\desc_q[a_x_addr][7]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h9AAA)) 
    \desc_q[a_x_addr][7]_i_7 
       (.I0(\way_inp_o[blk_offset] [0]),
        .I1(size[2]),
        .I2(size[0]),
        .I3(size[1]),
        .O(\desc_q[a_x_addr][7]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hAA9A)) 
    \desc_q[a_x_addr][7]_i_8 
       (.I0(\desc_q_reg[a_x_addr_n_0_][2] ),
        .I1(size[0]),
        .I2(size[1]),
        .I3(size[2]),
        .O(\desc_q[a_x_addr][7]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'hAAA6)) 
    \desc_q[a_x_addr][7]_i_9 
       (.I0(\desc_q_reg[a_x_addr_n_0_][1] ),
        .I1(size[0]),
        .I2(size[1]),
        .I3(size[2]),
        .O(\desc_q[a_x_addr][7]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][8]_i_1 
       (.I0(addr[8]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [8]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [8]));
  LUT4 #(
    .INIT(16'hF888)) 
    \desc_q[a_x_addr][9]_i_1 
       (.I0(addr[9]),
        .I1(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I2(\desc_i[a_x_addr] [9]),
        .I3(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_addr] [9]));
  LUT5 #(
    .INIT(32'h00AAFEAA)) 
    \desc_q[a_x_len][0]_i_1 
       (.I0(\desc_i[a_x_len] [0]),
        .I1(desc_ready_o_INST_0_i_1_n_0),
        .I2(\desc_q_reg[a_x_len] [7]),
        .I3(busy_q),
        .I4(\desc_q_reg[a_x_len] [0]),
        .O(\desc_d[a_x_len] [0]));
  LUT5 #(
    .INIT(32'hFF909090)) 
    \desc_q[a_x_len][1]_i_1 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(\desc_q_reg[a_x_len] [1]),
        .I2(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I3(\desc_i[a_x_len] [1]),
        .I4(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [1]));
  LUT6 #(
    .INIT(64'hFFFFE100E100E100)) 
    \desc_q[a_x_len][2]_i_1 
       (.I0(\desc_q_reg[a_x_len] [1]),
        .I1(\desc_q_reg[a_x_len] [0]),
        .I2(\desc_q_reg[a_x_len] [2]),
        .I3(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I4(\desc_i[a_x_len] [2]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [2]));
  LUT6 #(
    .INIT(64'hFFFFE100E100E100)) 
    \desc_q[a_x_len][3]_i_1 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(\desc_q[a_x_len][3]_i_2_n_0 ),
        .I2(\desc_q_reg[a_x_len] [3]),
        .I3(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I4(\desc_i[a_x_len] [3]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [3]));
  LUT2 #(
    .INIT(4'hE)) 
    \desc_q[a_x_len][3]_i_2 
       (.I0(\desc_q_reg[a_x_len] [1]),
        .I1(\desc_q_reg[a_x_len] [2]),
        .O(\desc_q[a_x_len][3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFE100E100E100)) 
    \desc_q[a_x_len][4]_i_1 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(\desc_q[a_x_len][4]_i_2_n_0 ),
        .I2(\desc_q_reg[a_x_len] [4]),
        .I3(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I4(\desc_i[a_x_len] [4]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [4]));
  LUT3 #(
    .INIT(8'hFE)) 
    \desc_q[a_x_len][4]_i_2 
       (.I0(\desc_q_reg[a_x_len] [2]),
        .I1(\desc_q_reg[a_x_len] [1]),
        .I2(\desc_q_reg[a_x_len] [3]),
        .O(\desc_q[a_x_len][4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFE100E100E100)) 
    \desc_q[a_x_len][5]_i_1 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(\desc_q[a_x_len][5]_i_2_n_0 ),
        .I2(\desc_q_reg[a_x_len] [5]),
        .I3(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I4(\desc_i[a_x_len] [5]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [5]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \desc_q[a_x_len][5]_i_2 
       (.I0(\desc_q_reg[a_x_len] [3]),
        .I1(\desc_q_reg[a_x_len] [1]),
        .I2(\desc_q_reg[a_x_len] [2]),
        .I3(\desc_q_reg[a_x_len] [4]),
        .O(\desc_q[a_x_len][5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFE100E100E100)) 
    \desc_q[a_x_len][6]_i_1 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(\desc_q[a_x_len][6]_i_2_n_0 ),
        .I2(\desc_q_reg[a_x_len] [6]),
        .I3(\desc_q[a_x_addr][13]_i_4_n_0 ),
        .I4(\desc_i[a_x_len] [6]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [6]));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \desc_q[a_x_len][6]_i_2 
       (.I0(\desc_q_reg[a_x_len] [4]),
        .I1(\desc_q_reg[a_x_len] [2]),
        .I2(\desc_q_reg[a_x_len] [1]),
        .I3(\desc_q_reg[a_x_len] [3]),
        .I4(\desc_q_reg[a_x_len] [5]),
        .O(\desc_q[a_x_len][6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hE0E0FFFFE0000000)) 
    \desc_q[a_x_len][7]_i_1 
       (.I0(\desc_q_reg[x_resp_n_0_][1] ),
        .I1(way_inp_ready_i),
        .I2(desc_ready_o_INST_0_i_2_n_0),
        .I3(w_unlock_req_o_INST_0_i_2_n_0),
        .I4(busy_q),
        .I5(desc_valid_i),
        .O(\desc_q[a_x_len][7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFE000E000E000)) 
    \desc_q[a_x_len][7]_i_2 
       (.I0(\desc_q_reg[a_x_len] [0]),
        .I1(desc_ready_o_INST_0_i_1_n_0),
        .I2(\desc_q_reg[a_x_len] [7]),
        .I3(busy_q),
        .I4(\desc_i[a_x_len] [7]),
        .I5(\desc_q[a_x_addr][13]_i_5_n_0 ),
        .O(\desc_d[a_x_len] [7]));
  LUT6 #(
    .INIT(64'h5555555D00000000)) 
    \desc_q[way_ind][7]_i_1 
       (.I0(busy_q),
        .I1(\desc_q[way_ind][7]_i_3_n_0 ),
        .I2(\desc_q_reg[a_x_len] [0]),
        .I3(desc_ready_o_INST_0_i_1_n_0),
        .I4(\desc_q_reg[a_x_len] [7]),
        .I5(desc_valid_i),
        .O(desc_q));
  LUT5 #(
    .INIT(32'h80808000)) 
    \desc_q[way_ind][7]_i_3 
       (.I0(w_valid),
        .I1(b_ready),
        .I2(w_unlock_gnt_i),
        .I3(way_inp_ready_i),
        .I4(\desc_q_reg[x_resp_n_0_][1] ),
        .O(\desc_q[way_ind][7]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][0] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [0]),
        .Q(\desc_q_reg[a_x_addr_n_0_][0] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][10] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [10]),
        .Q(\way_inp_o[line_addr] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][11] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [11]),
        .Q(\way_inp_o[line_addr] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][12] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [12]),
        .Q(\way_inp_o[line_addr] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][13] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [13]),
        .Q(\way_inp_o[line_addr] [7]));
  (* OPT_MODIFIED = "RETARGET SWEEP" *) 
  CARRY8 #(
    .CARRY_TYPE("SINGLE_CY8")) 
    \desc_q_reg[a_x_addr][13]_i_3 
       (.CI(\desc_q_reg[a_x_addr][7]_i_2_n_0 ),
        .CI_TOP(1'b0),
        .CO(\NLW_desc_q_reg[a_x_addr][13]_i_3_CO_UNCONNECTED [7:0]),
        .DI({\NLW_desc_q_reg[a_x_addr][13]_i_3_DI_UNCONNECTED [7:6],1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_desc_q_reg[a_x_addr][13]_i_3_O_UNCONNECTED [7:6],addr[13:8]}),
        .S({\NLW_desc_q_reg[a_x_addr][13]_i_3_S_UNCONNECTED [7:6],\way_inp_o[line_addr] [7:2]}));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][1] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [1]),
        .Q(\desc_q_reg[a_x_addr_n_0_][1] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][2] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [2]),
        .Q(\desc_q_reg[a_x_addr_n_0_][2] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][3] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [3]),
        .Q(\way_inp_o[blk_offset] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][4] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [4]),
        .Q(\way_inp_o[blk_offset] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][5] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [5]),
        .Q(\way_inp_o[blk_offset] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][6] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [6]),
        .Q(\way_inp_o[line_addr] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][7] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [7]),
        .Q(\way_inp_o[line_addr] [1]));
  (* OPT_MODIFIED = "SWEEP" *) 
  CARRY8 #(
    .CARRY_TYPE("SINGLE_CY8")) 
    \desc_q_reg[a_x_addr][7]_i_2 
       (.CI(1'b0),
        .CI_TOP(1'b0),
        .CO({\desc_q_reg[a_x_addr][7]_i_2_n_0 ,\NLW_desc_q_reg[a_x_addr][7]_i_2_CO_UNCONNECTED [6:0]}),
        .DI({\way_inp_o[line_addr] [1:0],\way_inp_o[blk_offset] ,\desc_q_reg[a_x_addr_n_0_][2] ,\desc_q_reg[a_x_addr_n_0_][1] ,\desc_q_reg[a_x_addr_n_0_][0] }),
        .O(addr[7:0]),
        .S({\desc_q[a_x_addr][7]_i_3_n_0 ,\desc_q[a_x_addr][7]_i_4_n_0 ,\desc_q[a_x_addr][7]_i_5_n_0 ,\desc_q[a_x_addr][7]_i_6_n_0 ,\desc_q[a_x_addr][7]_i_7_n_0 ,\desc_q[a_x_addr][7]_i_8_n_0 ,\desc_q[a_x_addr][7]_i_9_n_0 ,\desc_q[a_x_addr][7]_i_10_n_0 }));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][8] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [8]),
        .Q(\way_inp_o[line_addr] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_addr][9] 
       (.C(clk_i),
        .CE(\desc_q[a_x_addr][13]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_addr] [9]),
        .Q(\way_inp_o[line_addr] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_burst][0] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_burst] [0]),
        .Q(\desc_q_reg[a_x_burst] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_burst][1] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_burst] [1]),
        .Q(\desc_q_reg[a_x_burst] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_id][0] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_id] [0]),
        .Q(\desc_q_reg[a_x_id_n_0_][0] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_id][1] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_id] [1]),
        .Q(\desc_q_reg[a_x_id_n_0_][1] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_id][2] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_id] [2]),
        .Q(\desc_q_reg[a_x_id_n_0_][2] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_id][3] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_id] [3]),
        .Q(\desc_q_reg[a_x_id_n_0_][3] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][0] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [0]),
        .Q(\desc_q_reg[a_x_len] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][1] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [1]),
        .Q(\desc_q_reg[a_x_len] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][2] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [2]),
        .Q(\desc_q_reg[a_x_len] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][3] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [3]),
        .Q(\desc_q_reg[a_x_len] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][4] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [4]),
        .Q(\desc_q_reg[a_x_len] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][5] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [5]),
        .Q(\desc_q_reg[a_x_len] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][6] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [6]),
        .Q(\desc_q_reg[a_x_len] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_len][7] 
       (.C(clk_i),
        .CE(\desc_q[a_x_len][7]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\desc_d[a_x_len] [7]),
        .Q(\desc_q_reg[a_x_len] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_size][0] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_size] [0]),
        .Q(size[0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_size][1] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_size] [1]),
        .Q(size[1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[a_x_size][2] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[a_x_size] [2]),
        .Q(size[2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][0] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [0]),
        .Q(\way_inp_o[way_ind] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][1] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [1]),
        .Q(\way_inp_o[way_ind] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][2] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [2]),
        .Q(\way_inp_o[way_ind] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][3] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [3]),
        .Q(\way_inp_o[way_ind] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][4] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [4]),
        .Q(\way_inp_o[way_ind] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][5] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [5]),
        .Q(\way_inp_o[way_ind] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][6] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [6]),
        .Q(\way_inp_o[way_ind] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[way_ind][7] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[way_ind] [7]),
        .Q(\way_inp_o[way_ind] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[x_last] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[x_last] ),
        .Q(\desc_q_reg[x_last]__0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \desc_q_reg[x_resp][1] 
       (.C(clk_i),
        .CE(desc_q),
        .CLR(rst_ni),
        .D(\desc_i[x_resp] [1]),
        .Q(\desc_q_reg[x_resp_n_0_][1] ));
  LUT6 #(
    .INIT(64'h01000000FFFFFFFF)) 
    desc_ready_o_INST_0
       (.I0(\desc_q_reg[a_x_len] [7]),
        .I1(desc_ready_o_INST_0_i_1_n_0),
        .I2(\desc_q_reg[a_x_len] [0]),
        .I3(desc_ready_o_INST_0_i_2_n_0),
        .I4(desc_ready_o_INST_0_i_3_n_0),
        .I5(busy_q),
        .O(desc_ready_o));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    desc_ready_o_INST_0_i_1
       (.I0(\desc_q_reg[a_x_len] [5]),
        .I1(\desc_q_reg[a_x_len] [3]),
        .I2(\desc_q_reg[a_x_len] [1]),
        .I3(\desc_q_reg[a_x_len] [2]),
        .I4(\desc_q_reg[a_x_len] [4]),
        .I5(\desc_q_reg[a_x_len] [6]),
        .O(desc_ready_o_INST_0_i_1_n_0));
  LUT3 #(
    .INIT(8'h80)) 
    desc_ready_o_INST_0_i_2
       (.I0(w_unlock_gnt_i),
        .I1(b_ready),
        .I2(w_valid),
        .O(desc_ready_o_INST_0_i_2_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    desc_ready_o_INST_0_i_3
       (.I0(\desc_q_reg[x_resp_n_0_][1] ),
        .I1(way_inp_ready_i),
        .O(desc_ready_o_INST_0_i_3_n_0));
  (* Bypass = "1'b0" *) 
  spill_register__parameterized12__2 i_spill_register_b
       (.clk_i(clk_i),
        .\data_i[id] ({\desc_q_reg[a_x_id_n_0_][3] ,\desc_q_reg[a_x_id_n_0_][2] ,\desc_q_reg[a_x_id_n_0_][1] ,\desc_q_reg[a_x_id_n_0_][0] }),
        .\data_i[resp] ({\desc_q_reg[x_resp_n_0_][1] ,\NLW_i_spill_register_b_data_i[resp]_UNCONNECTED [0]}),
        .\data_i[user] (\NLW_i_spill_register_b_data_i[user]_UNCONNECTED [1:0]),
        .\data_o[id] (\b_chan_slv_o[id] ),
        .\data_o[resp] ({\b_chan_slv_o[resp] [1],\NLW_i_spill_register_b_data_o[resp]_UNCONNECTED [0]}),
        .\data_o[user] (\NLW_i_spill_register_b_data_o[user]_UNCONNECTED [1:0]),
        .ready_i(b_chan_ready_i),
        .ready_o(b_ready),
        .rst_ni(rst_ni),
        .valid_i(b_valid8_out),
        .valid_o(b_chan_valid_o));
  LUT3 #(
    .INIT(8'h08)) 
    i_spill_register_b_i_1
       (.I0(\desc_q_reg[x_last]__0 ),
        .I1(w_unlock_req_o_INST_0_i_1_n_0),
        .I2(w_unlock_req_o_INST_0_i_2_n_0),
        .O(b_valid8_out));
  (* ADDR_DEPTH = "32'b00000000000000000000000000000011" *) 
  (* DATA_WIDTH = "32'b00000000000000000000000000100000" *) 
  (* DEPTH = "6" *) 
  (* FALL_THROUGH = "1'b0" *) 
  stream_fifo__parameterized1 i_w_stream_fifo
       (.clk_i(clk_i),
        .\data_i[data] (\w_chan_slv_i[data] ),
        .\data_i[last] (\NLW_i_w_stream_fifo_data_i[last]_UNCONNECTED ),
        .\data_i[strb] (\w_chan_slv_i[strb] ),
        .\data_i[user] (\NLW_i_w_stream_fifo_data_i[user]_UNCONNECTED [1:0]),
        .\data_o[data] (\way_inp_o[data] ),
        .\data_o[last] (\NLW_i_w_stream_fifo_data_o[last]_UNCONNECTED ),
        .\data_o[strb] (\way_inp_o[strb] ),
        .\data_o[user] (\NLW_i_w_stream_fifo_data_o[user]_UNCONNECTED [1:0]),
        .flush_i(NLW_i_w_stream_fifo_flush_i_UNCONNECTED),
        .ready_i(w_ready5_out),
        .ready_o(w_chan_ready_o),
        .rst_ni(rst_ni),
        .testmode_i(NLW_i_w_stream_fifo_testmode_i_UNCONNECTED),
        .usage_o(NLW_i_w_stream_fifo_usage_o_UNCONNECTED[2:0]),
        .valid_i(w_chan_valid_i),
        .valid_o(w_valid));
  LUT5 #(
    .INIT(32'h80808000)) 
    i_w_stream_fifo_i_1
       (.I0(busy_q),
        .I1(b_ready),
        .I2(w_unlock_gnt_i),
        .I3(way_inp_ready_i),
        .I4(\desc_q_reg[x_resp_n_0_][1] ),
        .O(w_ready5_out));
  LUT2 #(
    .INIT(4'h2)) 
    w_unlock_req_o_INST_0
       (.I0(w_unlock_req_o_INST_0_i_1_n_0),
        .I1(w_unlock_req_o_INST_0_i_2_n_0),
        .O(w_unlock_req_o));
  LUT6 #(
    .INIT(64'h8000800080000000)) 
    w_unlock_req_o_INST_0_i_1
       (.I0(busy_q),
        .I1(w_unlock_gnt_i),
        .I2(b_ready),
        .I3(w_valid),
        .I4(way_inp_ready_i),
        .I5(\desc_q_reg[x_resp_n_0_][1] ),
        .O(w_unlock_req_o_INST_0_i_1_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    w_unlock_req_o_INST_0_i_2
       (.I0(\desc_q_reg[a_x_len] [7]),
        .I1(desc_ready_o_INST_0_i_1_n_0),
        .I2(\desc_q_reg[a_x_len] [0]),
        .O(w_unlock_req_o_INST_0_i_2_n_0));
  LUT5 #(
    .INIT(32'h00008000)) 
    way_inp_valid_o_INST_0
       (.I0(busy_q),
        .I1(w_unlock_gnt_i),
        .I2(b_ready),
        .I3(w_valid),
        .I4(\desc_q_reg[x_resp_n_0_][1] ),
        .O(way_inp_valid_o));
endmodule

(* ADDR_DEPTH = "32'b00000000000000000000000000000011" *) (* DATA_WIDTH = "32'b00000000000000000000000000100000" *) (* DEPTH = "6" *) 
(* FALL_THROUGH = "1'b0" *) (* FifoDepth = "6" *) (* ORIG_REF_NAME = "fifo_v3" *) 
module fifo_v3__parameterized13
   (clk_i,
    rst_ni,
    flush_i,
    testmode_i,
    full_o,
    empty_o,
    usage_o,
    \data_i[data] ,
    \data_i[strb] ,
    \data_i[last] ,
    \data_i[user] ,
    push_i,
    \data_o[data] ,
    \data_o[strb] ,
    \data_o[last] ,
    \data_o[user] ,
    pop_i);
  input clk_i;
  input rst_ni;
  input flush_i;
  input testmode_i;
  output full_o;
  output empty_o;
  output [2:0]usage_o;
  input [63:0]\data_i[data] ;
  input [7:0]\data_i[strb] ;
  input \data_i[last] ;
  input [1:0]\data_i[user] ;
  input push_i;
  output [63:0]\data_o[data] ;
  output [7:0]\data_o[strb] ;
  output \data_o[last] ;
  output [1:0]\data_o[user] ;
  input pop_i;

  wire clk_i;
  wire [63:0]\data_i[data] ;
  wire [7:0]\data_i[strb] ;
  wire [63:0]\data_o[data] ;
  wire \data_o[data][0]_INST_0_i_1_n_0 ;
  wire \data_o[data][10]_INST_0_i_1_n_0 ;
  wire \data_o[data][11]_INST_0_i_1_n_0 ;
  wire \data_o[data][12]_INST_0_i_1_n_0 ;
  wire \data_o[data][13]_INST_0_i_1_n_0 ;
  wire \data_o[data][14]_INST_0_i_1_n_0 ;
  wire \data_o[data][15]_INST_0_i_1_n_0 ;
  wire \data_o[data][16]_INST_0_i_1_n_0 ;
  wire \data_o[data][17]_INST_0_i_1_n_0 ;
  wire \data_o[data][18]_INST_0_i_1_n_0 ;
  wire \data_o[data][19]_INST_0_i_1_n_0 ;
  wire \data_o[data][1]_INST_0_i_1_n_0 ;
  wire \data_o[data][20]_INST_0_i_1_n_0 ;
  wire \data_o[data][21]_INST_0_i_1_n_0 ;
  wire \data_o[data][22]_INST_0_i_1_n_0 ;
  wire \data_o[data][23]_INST_0_i_1_n_0 ;
  wire \data_o[data][24]_INST_0_i_1_n_0 ;
  wire \data_o[data][25]_INST_0_i_1_n_0 ;
  wire \data_o[data][26]_INST_0_i_1_n_0 ;
  wire \data_o[data][27]_INST_0_i_1_n_0 ;
  wire \data_o[data][28]_INST_0_i_1_n_0 ;
  wire \data_o[data][29]_INST_0_i_1_n_0 ;
  wire \data_o[data][2]_INST_0_i_1_n_0 ;
  wire \data_o[data][30]_INST_0_i_1_n_0 ;
  wire \data_o[data][31]_INST_0_i_1_n_0 ;
  wire \data_o[data][32]_INST_0_i_1_n_0 ;
  wire \data_o[data][33]_INST_0_i_1_n_0 ;
  wire \data_o[data][34]_INST_0_i_1_n_0 ;
  wire \data_o[data][35]_INST_0_i_1_n_0 ;
  wire \data_o[data][36]_INST_0_i_1_n_0 ;
  wire \data_o[data][37]_INST_0_i_1_n_0 ;
  wire \data_o[data][38]_INST_0_i_1_n_0 ;
  wire \data_o[data][39]_INST_0_i_1_n_0 ;
  wire \data_o[data][3]_INST_0_i_1_n_0 ;
  wire \data_o[data][40]_INST_0_i_1_n_0 ;
  wire \data_o[data][41]_INST_0_i_1_n_0 ;
  wire \data_o[data][42]_INST_0_i_1_n_0 ;
  wire \data_o[data][43]_INST_0_i_1_n_0 ;
  wire \data_o[data][44]_INST_0_i_1_n_0 ;
  wire \data_o[data][45]_INST_0_i_1_n_0 ;
  wire \data_o[data][46]_INST_0_i_1_n_0 ;
  wire \data_o[data][47]_INST_0_i_1_n_0 ;
  wire \data_o[data][48]_INST_0_i_1_n_0 ;
  wire \data_o[data][49]_INST_0_i_1_n_0 ;
  wire \data_o[data][4]_INST_0_i_1_n_0 ;
  wire \data_o[data][50]_INST_0_i_1_n_0 ;
  wire \data_o[data][51]_INST_0_i_1_n_0 ;
  wire \data_o[data][52]_INST_0_i_1_n_0 ;
  wire \data_o[data][53]_INST_0_i_1_n_0 ;
  wire \data_o[data][54]_INST_0_i_1_n_0 ;
  wire \data_o[data][55]_INST_0_i_1_n_0 ;
  wire \data_o[data][56]_INST_0_i_1_n_0 ;
  wire \data_o[data][57]_INST_0_i_1_n_0 ;
  wire \data_o[data][58]_INST_0_i_1_n_0 ;
  wire \data_o[data][59]_INST_0_i_1_n_0 ;
  wire \data_o[data][5]_INST_0_i_1_n_0 ;
  wire \data_o[data][60]_INST_0_i_1_n_0 ;
  wire \data_o[data][61]_INST_0_i_1_n_0 ;
  wire \data_o[data][62]_INST_0_i_1_n_0 ;
  wire \data_o[data][63]_INST_0_i_1_n_0 ;
  wire \data_o[data][6]_INST_0_i_1_n_0 ;
  wire \data_o[data][7]_INST_0_i_1_n_0 ;
  wire \data_o[data][8]_INST_0_i_1_n_0 ;
  wire \data_o[data][9]_INST_0_i_1_n_0 ;
  wire [7:0]\data_o[strb] ;
  wire \data_o[strb][0]_INST_0_i_1_n_0 ;
  wire \data_o[strb][1]_INST_0_i_1_n_0 ;
  wire \data_o[strb][2]_INST_0_i_1_n_0 ;
  wire \data_o[strb][3]_INST_0_i_1_n_0 ;
  wire \data_o[strb][4]_INST_0_i_1_n_0 ;
  wire \data_o[strb][5]_INST_0_i_1_n_0 ;
  wire \data_o[strb][6]_INST_0_i_1_n_0 ;
  wire \data_o[strb][7]_INST_0_i_1_n_0 ;
  wire empty_o;
  wire full_o;
  wire mem_q;
  wire \mem_q[0][data][63]_i_1_n_0 ;
  wire \mem_q[1][data][63]_i_1_n_0 ;
  wire \mem_q[2][data][63]_i_1_n_0 ;
  wire \mem_q[3][data][63]_i_1_n_0 ;
  wire \mem_q[4][data][63]_i_1_n_0 ;
  wire [63:0]\mem_q_reg[0][data] ;
  wire [7:0]\mem_q_reg[0][strb] ;
  wire [63:0]\mem_q_reg[1][data] ;
  wire [7:0]\mem_q_reg[1][strb] ;
  wire [63:0]\mem_q_reg[2][data] ;
  wire [7:0]\mem_q_reg[2][strb] ;
  wire [63:0]\mem_q_reg[3][data] ;
  wire [7:0]\mem_q_reg[3][strb] ;
  wire [63:0]\mem_q_reg[4][data] ;
  wire [7:0]\mem_q_reg[4][strb] ;
  wire [63:0]\mem_q_reg[5][data] ;
  wire [7:0]\mem_q_reg[5][strb] ;
  wire pop_i;
  wire push_i;
  wire [2:0]read_pointer_q;
  wire read_pointer_q0;
  wire \read_pointer_q[0]_i_1_n_0 ;
  wire \read_pointer_q[1]_i_1_n_0 ;
  wire \read_pointer_q[2]_i_2_n_0 ;
  wire rst_ni;
  wire status_cnt_n;
  wire \status_cnt_q[0]_i_1_n_0 ;
  wire \status_cnt_q[1]_i_1_n_0 ;
  wire \status_cnt_q[2]_i_1_n_0 ;
  wire \status_cnt_q[3]_i_2_n_0 ;
  wire [3:3]status_cnt_q_reg;
  wire \status_cnt_q_reg_n_0_[0] ;
  wire \status_cnt_q_reg_n_0_[1] ;
  wire \status_cnt_q_reg_n_0_[2] ;
  wire [2:0]write_pointer_q;
  wire write_pointer_q0;
  wire \write_pointer_q[0]_i_1_n_0 ;
  wire \write_pointer_q[1]_i_1_n_0 ;
  wire \write_pointer_q[2]_i_2_n_0 ;

  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][0]_INST_0 
       (.I0(\mem_q_reg[5][data] [0]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [0]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][0]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][0]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [0]),
        .I1(\mem_q_reg[2][data] [0]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [0]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [0]),
        .O(\data_o[data][0]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][10]_INST_0 
       (.I0(\mem_q_reg[5][data] [10]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [10]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][10]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][10]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [10]),
        .I1(\mem_q_reg[2][data] [10]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [10]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [10]),
        .O(\data_o[data][10]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][11]_INST_0 
       (.I0(\mem_q_reg[5][data] [11]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [11]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][11]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][11]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [11]),
        .I1(\mem_q_reg[2][data] [11]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [11]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [11]),
        .O(\data_o[data][11]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][12]_INST_0 
       (.I0(\mem_q_reg[5][data] [12]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [12]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][12]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [12]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][12]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [12]),
        .I1(\mem_q_reg[2][data] [12]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [12]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [12]),
        .O(\data_o[data][12]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][13]_INST_0 
       (.I0(\mem_q_reg[5][data] [13]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [13]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][13]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [13]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][13]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [13]),
        .I1(\mem_q_reg[2][data] [13]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [13]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [13]),
        .O(\data_o[data][13]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][14]_INST_0 
       (.I0(\mem_q_reg[5][data] [14]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [14]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][14]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][14]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [14]),
        .I1(\mem_q_reg[2][data] [14]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [14]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [14]),
        .O(\data_o[data][14]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][15]_INST_0 
       (.I0(\mem_q_reg[5][data] [15]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [15]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][15]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][15]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [15]),
        .I1(\mem_q_reg[2][data] [15]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [15]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [15]),
        .O(\data_o[data][15]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][16]_INST_0 
       (.I0(\mem_q_reg[5][data] [16]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [16]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][16]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [16]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][16]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [16]),
        .I1(\mem_q_reg[2][data] [16]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [16]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [16]),
        .O(\data_o[data][16]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][17]_INST_0 
       (.I0(\mem_q_reg[5][data] [17]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [17]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][17]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][17]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [17]),
        .I1(\mem_q_reg[2][data] [17]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [17]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [17]),
        .O(\data_o[data][17]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][18]_INST_0 
       (.I0(\mem_q_reg[5][data] [18]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [18]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][18]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [18]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][18]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [18]),
        .I1(\mem_q_reg[2][data] [18]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [18]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [18]),
        .O(\data_o[data][18]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][19]_INST_0 
       (.I0(\mem_q_reg[5][data] [19]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [19]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][19]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [19]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][19]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [19]),
        .I1(\mem_q_reg[2][data] [19]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [19]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [19]),
        .O(\data_o[data][19]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][1]_INST_0 
       (.I0(\mem_q_reg[5][data] [1]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [1]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][1]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][1]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [1]),
        .I1(\mem_q_reg[2][data] [1]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [1]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [1]),
        .O(\data_o[data][1]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][20]_INST_0 
       (.I0(\mem_q_reg[5][data] [20]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [20]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][20]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [20]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][20]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [20]),
        .I1(\mem_q_reg[2][data] [20]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [20]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [20]),
        .O(\data_o[data][20]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][21]_INST_0 
       (.I0(\mem_q_reg[5][data] [21]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [21]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][21]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [21]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][21]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [21]),
        .I1(\mem_q_reg[2][data] [21]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [21]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [21]),
        .O(\data_o[data][21]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][22]_INST_0 
       (.I0(\mem_q_reg[5][data] [22]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [22]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][22]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [22]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][22]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [22]),
        .I1(\mem_q_reg[2][data] [22]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [22]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [22]),
        .O(\data_o[data][22]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][23]_INST_0 
       (.I0(\mem_q_reg[5][data] [23]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [23]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][23]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [23]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][23]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [23]),
        .I1(\mem_q_reg[2][data] [23]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [23]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [23]),
        .O(\data_o[data][23]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][24]_INST_0 
       (.I0(\mem_q_reg[5][data] [24]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [24]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][24]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [24]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][24]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [24]),
        .I1(\mem_q_reg[2][data] [24]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [24]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [24]),
        .O(\data_o[data][24]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][25]_INST_0 
       (.I0(\mem_q_reg[5][data] [25]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [25]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][25]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [25]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][25]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [25]),
        .I1(\mem_q_reg[2][data] [25]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [25]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [25]),
        .O(\data_o[data][25]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][26]_INST_0 
       (.I0(\mem_q_reg[5][data] [26]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [26]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][26]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [26]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][26]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [26]),
        .I1(\mem_q_reg[2][data] [26]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [26]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [26]),
        .O(\data_o[data][26]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][27]_INST_0 
       (.I0(\mem_q_reg[5][data] [27]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [27]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][27]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [27]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][27]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [27]),
        .I1(\mem_q_reg[2][data] [27]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [27]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [27]),
        .O(\data_o[data][27]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][28]_INST_0 
       (.I0(\mem_q_reg[5][data] [28]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [28]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][28]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [28]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][28]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [28]),
        .I1(\mem_q_reg[2][data] [28]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [28]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [28]),
        .O(\data_o[data][28]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][29]_INST_0 
       (.I0(\mem_q_reg[5][data] [29]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [29]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][29]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [29]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][29]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [29]),
        .I1(\mem_q_reg[2][data] [29]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [29]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [29]),
        .O(\data_o[data][29]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][2]_INST_0 
       (.I0(\mem_q_reg[5][data] [2]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [2]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][2]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][2]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [2]),
        .I1(\mem_q_reg[2][data] [2]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [2]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [2]),
        .O(\data_o[data][2]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][30]_INST_0 
       (.I0(\mem_q_reg[5][data] [30]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [30]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][30]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [30]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][30]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [30]),
        .I1(\mem_q_reg[2][data] [30]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [30]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [30]),
        .O(\data_o[data][30]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][31]_INST_0 
       (.I0(\mem_q_reg[5][data] [31]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [31]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][31]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [31]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][31]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [31]),
        .I1(\mem_q_reg[2][data] [31]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [31]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [31]),
        .O(\data_o[data][31]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][32]_INST_0 
       (.I0(\mem_q_reg[5][data] [32]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [32]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][32]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [32]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][32]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [32]),
        .I1(\mem_q_reg[2][data] [32]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [32]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [32]),
        .O(\data_o[data][32]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][33]_INST_0 
       (.I0(\mem_q_reg[5][data] [33]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [33]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][33]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [33]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][33]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [33]),
        .I1(\mem_q_reg[2][data] [33]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [33]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [33]),
        .O(\data_o[data][33]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][34]_INST_0 
       (.I0(\mem_q_reg[5][data] [34]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [34]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][34]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [34]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][34]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [34]),
        .I1(\mem_q_reg[2][data] [34]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [34]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [34]),
        .O(\data_o[data][34]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][35]_INST_0 
       (.I0(\mem_q_reg[5][data] [35]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [35]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][35]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [35]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][35]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [35]),
        .I1(\mem_q_reg[2][data] [35]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [35]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [35]),
        .O(\data_o[data][35]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][36]_INST_0 
       (.I0(\mem_q_reg[5][data] [36]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [36]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][36]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [36]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][36]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [36]),
        .I1(\mem_q_reg[2][data] [36]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [36]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [36]),
        .O(\data_o[data][36]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][37]_INST_0 
       (.I0(\mem_q_reg[5][data] [37]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [37]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][37]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [37]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][37]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [37]),
        .I1(\mem_q_reg[2][data] [37]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [37]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [37]),
        .O(\data_o[data][37]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][38]_INST_0 
       (.I0(\mem_q_reg[5][data] [38]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [38]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][38]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [38]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][38]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [38]),
        .I1(\mem_q_reg[2][data] [38]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [38]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [38]),
        .O(\data_o[data][38]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][39]_INST_0 
       (.I0(\mem_q_reg[5][data] [39]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [39]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][39]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [39]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][39]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [39]),
        .I1(\mem_q_reg[2][data] [39]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [39]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [39]),
        .O(\data_o[data][39]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][3]_INST_0 
       (.I0(\mem_q_reg[5][data] [3]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [3]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][3]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][3]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [3]),
        .I1(\mem_q_reg[2][data] [3]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [3]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [3]),
        .O(\data_o[data][3]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][40]_INST_0 
       (.I0(\mem_q_reg[5][data] [40]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [40]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][40]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [40]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][40]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [40]),
        .I1(\mem_q_reg[2][data] [40]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [40]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [40]),
        .O(\data_o[data][40]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][41]_INST_0 
       (.I0(\mem_q_reg[5][data] [41]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [41]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][41]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [41]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][41]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [41]),
        .I1(\mem_q_reg[2][data] [41]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [41]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [41]),
        .O(\data_o[data][41]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][42]_INST_0 
       (.I0(\mem_q_reg[5][data] [42]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [42]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][42]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [42]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][42]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [42]),
        .I1(\mem_q_reg[2][data] [42]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [42]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [42]),
        .O(\data_o[data][42]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][43]_INST_0 
       (.I0(\mem_q_reg[5][data] [43]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [43]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][43]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [43]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][43]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [43]),
        .I1(\mem_q_reg[2][data] [43]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [43]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [43]),
        .O(\data_o[data][43]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][44]_INST_0 
       (.I0(\mem_q_reg[5][data] [44]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [44]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][44]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [44]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][44]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [44]),
        .I1(\mem_q_reg[2][data] [44]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [44]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [44]),
        .O(\data_o[data][44]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][45]_INST_0 
       (.I0(\mem_q_reg[5][data] [45]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [45]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][45]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [45]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][45]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [45]),
        .I1(\mem_q_reg[2][data] [45]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [45]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [45]),
        .O(\data_o[data][45]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][46]_INST_0 
       (.I0(\mem_q_reg[5][data] [46]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [46]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][46]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [46]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][46]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [46]),
        .I1(\mem_q_reg[2][data] [46]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [46]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [46]),
        .O(\data_o[data][46]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][47]_INST_0 
       (.I0(\mem_q_reg[5][data] [47]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [47]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][47]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [47]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][47]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [47]),
        .I1(\mem_q_reg[2][data] [47]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [47]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [47]),
        .O(\data_o[data][47]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][48]_INST_0 
       (.I0(\mem_q_reg[5][data] [48]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [48]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][48]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [48]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][48]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [48]),
        .I1(\mem_q_reg[2][data] [48]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [48]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [48]),
        .O(\data_o[data][48]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][49]_INST_0 
       (.I0(\mem_q_reg[5][data] [49]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [49]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][49]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [49]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][49]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [49]),
        .I1(\mem_q_reg[2][data] [49]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [49]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [49]),
        .O(\data_o[data][49]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][4]_INST_0 
       (.I0(\mem_q_reg[5][data] [4]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [4]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][4]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][4]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [4]),
        .I1(\mem_q_reg[2][data] [4]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [4]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [4]),
        .O(\data_o[data][4]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][50]_INST_0 
       (.I0(\mem_q_reg[5][data] [50]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [50]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][50]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [50]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][50]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [50]),
        .I1(\mem_q_reg[2][data] [50]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [50]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [50]),
        .O(\data_o[data][50]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][51]_INST_0 
       (.I0(\mem_q_reg[5][data] [51]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [51]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][51]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [51]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][51]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [51]),
        .I1(\mem_q_reg[2][data] [51]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [51]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [51]),
        .O(\data_o[data][51]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][52]_INST_0 
       (.I0(\mem_q_reg[5][data] [52]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [52]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][52]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [52]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][52]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [52]),
        .I1(\mem_q_reg[2][data] [52]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [52]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [52]),
        .O(\data_o[data][52]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][53]_INST_0 
       (.I0(\mem_q_reg[5][data] [53]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [53]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][53]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [53]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][53]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [53]),
        .I1(\mem_q_reg[2][data] [53]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [53]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [53]),
        .O(\data_o[data][53]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][54]_INST_0 
       (.I0(\mem_q_reg[5][data] [54]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [54]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][54]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [54]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][54]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [54]),
        .I1(\mem_q_reg[2][data] [54]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [54]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [54]),
        .O(\data_o[data][54]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][55]_INST_0 
       (.I0(\mem_q_reg[5][data] [55]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [55]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][55]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [55]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][55]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [55]),
        .I1(\mem_q_reg[2][data] [55]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [55]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [55]),
        .O(\data_o[data][55]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][56]_INST_0 
       (.I0(\mem_q_reg[5][data] [56]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [56]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][56]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [56]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][56]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [56]),
        .I1(\mem_q_reg[2][data] [56]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [56]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [56]),
        .O(\data_o[data][56]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][57]_INST_0 
       (.I0(\mem_q_reg[5][data] [57]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [57]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][57]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [57]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][57]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [57]),
        .I1(\mem_q_reg[2][data] [57]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [57]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [57]),
        .O(\data_o[data][57]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][58]_INST_0 
       (.I0(\mem_q_reg[5][data] [58]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [58]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][58]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [58]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][58]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [58]),
        .I1(\mem_q_reg[2][data] [58]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [58]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [58]),
        .O(\data_o[data][58]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][59]_INST_0 
       (.I0(\mem_q_reg[5][data] [59]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [59]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][59]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [59]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][59]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [59]),
        .I1(\mem_q_reg[2][data] [59]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [59]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [59]),
        .O(\data_o[data][59]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][5]_INST_0 
       (.I0(\mem_q_reg[5][data] [5]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [5]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][5]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][5]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [5]),
        .I1(\mem_q_reg[2][data] [5]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [5]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [5]),
        .O(\data_o[data][5]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][60]_INST_0 
       (.I0(\mem_q_reg[5][data] [60]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [60]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][60]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [60]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][60]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [60]),
        .I1(\mem_q_reg[2][data] [60]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [60]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [60]),
        .O(\data_o[data][60]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][61]_INST_0 
       (.I0(\mem_q_reg[5][data] [61]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [61]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][61]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [61]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][61]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [61]),
        .I1(\mem_q_reg[2][data] [61]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [61]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [61]),
        .O(\data_o[data][61]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][62]_INST_0 
       (.I0(\mem_q_reg[5][data] [62]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [62]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][62]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [62]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][62]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [62]),
        .I1(\mem_q_reg[2][data] [62]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [62]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [62]),
        .O(\data_o[data][62]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][63]_INST_0 
       (.I0(\mem_q_reg[5][data] [63]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [63]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][63]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [63]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][63]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [63]),
        .I1(\mem_q_reg[2][data] [63]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [63]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [63]),
        .O(\data_o[data][63]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][6]_INST_0 
       (.I0(\mem_q_reg[5][data] [6]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [6]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][6]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][6]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [6]),
        .I1(\mem_q_reg[2][data] [6]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [6]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [6]),
        .O(\data_o[data][6]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][7]_INST_0 
       (.I0(\mem_q_reg[5][data] [7]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [7]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][7]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][7]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [7]),
        .I1(\mem_q_reg[2][data] [7]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [7]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [7]),
        .O(\data_o[data][7]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][8]_INST_0 
       (.I0(\mem_q_reg[5][data] [8]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [8]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][8]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][8]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [8]),
        .I1(\mem_q_reg[2][data] [8]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [8]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [8]),
        .O(\data_o[data][8]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[data][9]_INST_0 
       (.I0(\mem_q_reg[5][data] [9]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][data] [9]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[data][9]_INST_0_i_1_n_0 ),
        .O(\data_o[data] [9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[data][9]_INST_0_i_1 
       (.I0(\mem_q_reg[3][data] [9]),
        .I1(\mem_q_reg[2][data] [9]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][data] [9]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][data] [9]),
        .O(\data_o[data][9]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][0]_INST_0 
       (.I0(\mem_q_reg[5][strb] [0]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [0]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][0]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][0]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [0]),
        .I1(\mem_q_reg[2][strb] [0]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [0]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [0]),
        .O(\data_o[strb][0]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][1]_INST_0 
       (.I0(\mem_q_reg[5][strb] [1]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [1]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][1]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][1]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [1]),
        .I1(\mem_q_reg[2][strb] [1]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [1]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [1]),
        .O(\data_o[strb][1]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][2]_INST_0 
       (.I0(\mem_q_reg[5][strb] [2]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [2]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][2]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][2]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [2]),
        .I1(\mem_q_reg[2][strb] [2]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [2]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [2]),
        .O(\data_o[strb][2]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][3]_INST_0 
       (.I0(\mem_q_reg[5][strb] [3]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [3]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][3]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][3]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [3]),
        .I1(\mem_q_reg[2][strb] [3]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [3]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [3]),
        .O(\data_o[strb][3]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][4]_INST_0 
       (.I0(\mem_q_reg[5][strb] [4]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [4]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][4]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][4]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [4]),
        .I1(\mem_q_reg[2][strb] [4]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [4]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [4]),
        .O(\data_o[strb][4]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][5]_INST_0 
       (.I0(\mem_q_reg[5][strb] [5]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [5]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][5]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][5]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [5]),
        .I1(\mem_q_reg[2][strb] [5]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [5]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [5]),
        .O(\data_o[strb][5]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][6]_INST_0 
       (.I0(\mem_q_reg[5][strb] [6]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [6]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][6]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][6]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [6]),
        .I1(\mem_q_reg[2][strb] [6]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [6]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [6]),
        .O(\data_o[strb][6]_INST_0_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \data_o[strb][7]_INST_0 
       (.I0(\mem_q_reg[5][strb] [7]),
        .I1(read_pointer_q[0]),
        .I2(\mem_q_reg[4][strb] [7]),
        .I3(read_pointer_q[2]),
        .I4(\data_o[strb][7]_INST_0_i_1_n_0 ),
        .O(\data_o[strb] [7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \data_o[strb][7]_INST_0_i_1 
       (.I0(\mem_q_reg[3][strb] [7]),
        .I1(\mem_q_reg[2][strb] [7]),
        .I2(read_pointer_q[1]),
        .I3(\mem_q_reg[1][strb] [7]),
        .I4(read_pointer_q[0]),
        .I5(\mem_q_reg[0][strb] [7]),
        .O(\data_o[strb][7]_INST_0_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    empty_o_INST_0
       (.I0(\status_cnt_q_reg_n_0_[2] ),
        .I1(status_cnt_q_reg),
        .I2(\status_cnt_q_reg_n_0_[1] ),
        .I3(\status_cnt_q_reg_n_0_[0] ),
        .O(empty_o));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT4 #(
    .INIT(16'hEFFF)) 
    full_o_INST_0
       (.I0(status_cnt_q_reg),
        .I1(\status_cnt_q_reg_n_0_[0] ),
        .I2(\status_cnt_q_reg_n_0_[2] ),
        .I3(\status_cnt_q_reg_n_0_[1] ),
        .O(full_o));
  LUT4 #(
    .INIT(16'h0100)) 
    \mem_q[0][data][63]_i_1 
       (.I0(write_pointer_q[2]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[1]),
        .I3(write_pointer_q0),
        .O(\mem_q[0][data][63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \mem_q[1][data][63]_i_1 
       (.I0(write_pointer_q[2]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[1]),
        .I3(write_pointer_q0),
        .O(\mem_q[1][data][63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \mem_q[2][data][63]_i_1 
       (.I0(write_pointer_q[0]),
        .I1(write_pointer_q[1]),
        .I2(write_pointer_q[2]),
        .I3(write_pointer_q0),
        .O(\mem_q[2][data][63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0800)) 
    \mem_q[3][data][63]_i_1 
       (.I0(write_pointer_q[1]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[2]),
        .I3(write_pointer_q0),
        .O(\mem_q[3][data][63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \mem_q[4][data][63]_i_1 
       (.I0(write_pointer_q[0]),
        .I1(write_pointer_q[2]),
        .I2(write_pointer_q[1]),
        .I3(write_pointer_q0),
        .O(\mem_q[4][data][63]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0800)) 
    \mem_q[5][data][63]_i_1 
       (.I0(write_pointer_q[2]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[1]),
        .I3(write_pointer_q0),
        .O(mem_q));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][0] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[0][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][10] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[0][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][11] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[0][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][12] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[0][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][13] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[0][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][14] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[0][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][15] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[0][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][16] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[0][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][17] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[0][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][18] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[0][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][19] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[0][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][1] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[0][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][20] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[0][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][21] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[0][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][22] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[0][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][23] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[0][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][24] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[0][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][25] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[0][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][26] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[0][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][27] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[0][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][28] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[0][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][29] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[0][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][2] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[0][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][30] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[0][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][31] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[0][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][32] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[0][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][33] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[0][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][34] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[0][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][35] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[0][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][36] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[0][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][37] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[0][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][38] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[0][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][39] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[0][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][3] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[0][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][40] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[0][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][41] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[0][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][42] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[0][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][43] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[0][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][44] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[0][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][45] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[0][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][46] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[0][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][47] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[0][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][48] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[0][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][49] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[0][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][4] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[0][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][50] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[0][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][51] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[0][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][52] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[0][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][53] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[0][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][54] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[0][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][55] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[0][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][56] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[0][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][57] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[0][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][58] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[0][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][59] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[0][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][5] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[0][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][60] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[0][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][61] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[0][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][62] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[0][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][63] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[0][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][6] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[0][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][7] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[0][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][8] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[0][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][data][9] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[0][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][0] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[0][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][1] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[0][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][2] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[0][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][3] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[0][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][4] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[0][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][5] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[0][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][6] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[0][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[0][strb][7] 
       (.C(clk_i),
        .CE(\mem_q[0][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[0][strb] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][0] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[1][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][10] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[1][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][11] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[1][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][12] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[1][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][13] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[1][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][14] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[1][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][15] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[1][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][16] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[1][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][17] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[1][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][18] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[1][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][19] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[1][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][1] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[1][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][20] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[1][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][21] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[1][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][22] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[1][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][23] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[1][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][24] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[1][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][25] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[1][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][26] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[1][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][27] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[1][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][28] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[1][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][29] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[1][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][2] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[1][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][30] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[1][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][31] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[1][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][32] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[1][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][33] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[1][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][34] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[1][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][35] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[1][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][36] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[1][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][37] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[1][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][38] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[1][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][39] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[1][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][3] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[1][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][40] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[1][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][41] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[1][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][42] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[1][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][43] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[1][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][44] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[1][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][45] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[1][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][46] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[1][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][47] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[1][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][48] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[1][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][49] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[1][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][4] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[1][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][50] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[1][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][51] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[1][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][52] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[1][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][53] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[1][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][54] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[1][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][55] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[1][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][56] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[1][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][57] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[1][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][58] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[1][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][59] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[1][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][5] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[1][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][60] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[1][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][61] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[1][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][62] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[1][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][63] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[1][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][6] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[1][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][7] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[1][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][8] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[1][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][data][9] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[1][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][0] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[1][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][1] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[1][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][2] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[1][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][3] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[1][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][4] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[1][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][5] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[1][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][6] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[1][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[1][strb][7] 
       (.C(clk_i),
        .CE(\mem_q[1][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[1][strb] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][0] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[2][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][10] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[2][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][11] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[2][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][12] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[2][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][13] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[2][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][14] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[2][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][15] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[2][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][16] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[2][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][17] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[2][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][18] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[2][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][19] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[2][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][1] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[2][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][20] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[2][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][21] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[2][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][22] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[2][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][23] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[2][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][24] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[2][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][25] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[2][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][26] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[2][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][27] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[2][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][28] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[2][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][29] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[2][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][2] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[2][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][30] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[2][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][31] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[2][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][32] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[2][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][33] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[2][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][34] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[2][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][35] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[2][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][36] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[2][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][37] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[2][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][38] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[2][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][39] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[2][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][3] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[2][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][40] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[2][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][41] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[2][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][42] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[2][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][43] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[2][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][44] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[2][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][45] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[2][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][46] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[2][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][47] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[2][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][48] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[2][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][49] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[2][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][4] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[2][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][50] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[2][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][51] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[2][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][52] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[2][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][53] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[2][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][54] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[2][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][55] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[2][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][56] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[2][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][57] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[2][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][58] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[2][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][59] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[2][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][5] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[2][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][60] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[2][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][61] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[2][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][62] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[2][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][63] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[2][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][6] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[2][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][7] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[2][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][8] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[2][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][data][9] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[2][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][0] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[2][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][1] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[2][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][2] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[2][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][3] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[2][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][4] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[2][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][5] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[2][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][6] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[2][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[2][strb][7] 
       (.C(clk_i),
        .CE(\mem_q[2][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[2][strb] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][0] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[3][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][10] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[3][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][11] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[3][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][12] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[3][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][13] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[3][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][14] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[3][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][15] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[3][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][16] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[3][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][17] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[3][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][18] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[3][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][19] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[3][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][1] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[3][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][20] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[3][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][21] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[3][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][22] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[3][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][23] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[3][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][24] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[3][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][25] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[3][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][26] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[3][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][27] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[3][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][28] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[3][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][29] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[3][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][2] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[3][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][30] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[3][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][31] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[3][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][32] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[3][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][33] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[3][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][34] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[3][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][35] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[3][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][36] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[3][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][37] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[3][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][38] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[3][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][39] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[3][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][3] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[3][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][40] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[3][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][41] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[3][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][42] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[3][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][43] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[3][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][44] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[3][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][45] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[3][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][46] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[3][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][47] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[3][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][48] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[3][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][49] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[3][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][4] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[3][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][50] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[3][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][51] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[3][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][52] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[3][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][53] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[3][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][54] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[3][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][55] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[3][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][56] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[3][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][57] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[3][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][58] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[3][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][59] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[3][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][5] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[3][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][60] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[3][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][61] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[3][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][62] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[3][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][63] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[3][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][6] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[3][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][7] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[3][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][8] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[3][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][data][9] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[3][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][0] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[3][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][1] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[3][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][2] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[3][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][3] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[3][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][4] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[3][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][5] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[3][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][6] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[3][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[3][strb][7] 
       (.C(clk_i),
        .CE(\mem_q[3][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[3][strb] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][0] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[4][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][10] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[4][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][11] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[4][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][12] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[4][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][13] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[4][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][14] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[4][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][15] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[4][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][16] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[4][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][17] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[4][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][18] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[4][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][19] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[4][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][1] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[4][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][20] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[4][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][21] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[4][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][22] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[4][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][23] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[4][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][24] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[4][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][25] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[4][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][26] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[4][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][27] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[4][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][28] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[4][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][29] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[4][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][2] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[4][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][30] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[4][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][31] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[4][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][32] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[4][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][33] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[4][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][34] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[4][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][35] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[4][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][36] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[4][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][37] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[4][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][38] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[4][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][39] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[4][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][3] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[4][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][40] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[4][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][41] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[4][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][42] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[4][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][43] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[4][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][44] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[4][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][45] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[4][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][46] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[4][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][47] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[4][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][48] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[4][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][49] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[4][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][4] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[4][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][50] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[4][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][51] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[4][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][52] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[4][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][53] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[4][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][54] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[4][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][55] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[4][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][56] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[4][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][57] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[4][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][58] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[4][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][59] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[4][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][5] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[4][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][60] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[4][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][61] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[4][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][62] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[4][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][63] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[4][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][6] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[4][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][7] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[4][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][8] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[4][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][data][9] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[4][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][0] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[4][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][1] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[4][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][2] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[4][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][3] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[4][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][4] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[4][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][5] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[4][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][6] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[4][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[4][strb][7] 
       (.C(clk_i),
        .CE(\mem_q[4][data][63]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[4][strb] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][0] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [0]),
        .Q(\mem_q_reg[5][data] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][10] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [10]),
        .Q(\mem_q_reg[5][data] [10]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][11] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [11]),
        .Q(\mem_q_reg[5][data] [11]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][12] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [12]),
        .Q(\mem_q_reg[5][data] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][13] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [13]),
        .Q(\mem_q_reg[5][data] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][14] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [14]),
        .Q(\mem_q_reg[5][data] [14]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][15] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [15]),
        .Q(\mem_q_reg[5][data] [15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][16] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [16]),
        .Q(\mem_q_reg[5][data] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][17] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [17]),
        .Q(\mem_q_reg[5][data] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][18] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [18]),
        .Q(\mem_q_reg[5][data] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][19] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [19]),
        .Q(\mem_q_reg[5][data] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][1] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [1]),
        .Q(\mem_q_reg[5][data] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][20] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [20]),
        .Q(\mem_q_reg[5][data] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][21] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [21]),
        .Q(\mem_q_reg[5][data] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][22] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [22]),
        .Q(\mem_q_reg[5][data] [22]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][23] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [23]),
        .Q(\mem_q_reg[5][data] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][24] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [24]),
        .Q(\mem_q_reg[5][data] [24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][25] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [25]),
        .Q(\mem_q_reg[5][data] [25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][26] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [26]),
        .Q(\mem_q_reg[5][data] [26]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][27] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [27]),
        .Q(\mem_q_reg[5][data] [27]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][28] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [28]),
        .Q(\mem_q_reg[5][data] [28]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][29] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [29]),
        .Q(\mem_q_reg[5][data] [29]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][2] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [2]),
        .Q(\mem_q_reg[5][data] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][30] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [30]),
        .Q(\mem_q_reg[5][data] [30]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][31] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [31]),
        .Q(\mem_q_reg[5][data] [31]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][32] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [32]),
        .Q(\mem_q_reg[5][data] [32]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][33] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [33]),
        .Q(\mem_q_reg[5][data] [33]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][34] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [34]),
        .Q(\mem_q_reg[5][data] [34]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][35] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [35]),
        .Q(\mem_q_reg[5][data] [35]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][36] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [36]),
        .Q(\mem_q_reg[5][data] [36]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][37] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [37]),
        .Q(\mem_q_reg[5][data] [37]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][38] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [38]),
        .Q(\mem_q_reg[5][data] [38]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][39] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [39]),
        .Q(\mem_q_reg[5][data] [39]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][3] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [3]),
        .Q(\mem_q_reg[5][data] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][40] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [40]),
        .Q(\mem_q_reg[5][data] [40]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][41] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [41]),
        .Q(\mem_q_reg[5][data] [41]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][42] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [42]),
        .Q(\mem_q_reg[5][data] [42]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][43] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [43]),
        .Q(\mem_q_reg[5][data] [43]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][44] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [44]),
        .Q(\mem_q_reg[5][data] [44]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][45] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [45]),
        .Q(\mem_q_reg[5][data] [45]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][46] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [46]),
        .Q(\mem_q_reg[5][data] [46]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][47] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [47]),
        .Q(\mem_q_reg[5][data] [47]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][48] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [48]),
        .Q(\mem_q_reg[5][data] [48]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][49] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [49]),
        .Q(\mem_q_reg[5][data] [49]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][4] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [4]),
        .Q(\mem_q_reg[5][data] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][50] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [50]),
        .Q(\mem_q_reg[5][data] [50]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][51] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [51]),
        .Q(\mem_q_reg[5][data] [51]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][52] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [52]),
        .Q(\mem_q_reg[5][data] [52]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][53] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [53]),
        .Q(\mem_q_reg[5][data] [53]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][54] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [54]),
        .Q(\mem_q_reg[5][data] [54]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][55] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [55]),
        .Q(\mem_q_reg[5][data] [55]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][56] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [56]),
        .Q(\mem_q_reg[5][data] [56]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][57] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [57]),
        .Q(\mem_q_reg[5][data] [57]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][58] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [58]),
        .Q(\mem_q_reg[5][data] [58]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][59] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [59]),
        .Q(\mem_q_reg[5][data] [59]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][5] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [5]),
        .Q(\mem_q_reg[5][data] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][60] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [60]),
        .Q(\mem_q_reg[5][data] [60]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][61] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [61]),
        .Q(\mem_q_reg[5][data] [61]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][62] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [62]),
        .Q(\mem_q_reg[5][data] [62]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][63] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [63]),
        .Q(\mem_q_reg[5][data] [63]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][6] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [6]),
        .Q(\mem_q_reg[5][data] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][7] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [7]),
        .Q(\mem_q_reg[5][data] [7]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][8] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [8]),
        .Q(\mem_q_reg[5][data] [8]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][data][9] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[data] [9]),
        .Q(\mem_q_reg[5][data] [9]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][0] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [0]),
        .Q(\mem_q_reg[5][strb] [0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][1] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [1]),
        .Q(\mem_q_reg[5][strb] [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][2] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [2]),
        .Q(\mem_q_reg[5][strb] [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][3] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [3]),
        .Q(\mem_q_reg[5][strb] [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][4] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [4]),
        .Q(\mem_q_reg[5][strb] [4]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][5] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [5]),
        .Q(\mem_q_reg[5][strb] [5]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][6] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [6]),
        .Q(\mem_q_reg[5][strb] [6]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \mem_q_reg[5][strb][7] 
       (.C(clk_i),
        .CE(mem_q),
        .CLR(rst_ni),
        .D(\data_i[strb] [7]),
        .Q(\mem_q_reg[5][strb] [7]));
  LUT1 #(
    .INIT(2'h1)) 
    \read_pointer_q[0]_i_1 
       (.I0(read_pointer_q[0]),
        .O(\read_pointer_q[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5854" *) 
  LUT3 #(
    .INIT(8'h52)) 
    \read_pointer_q[1]_i_1 
       (.I0(read_pointer_q[0]),
        .I1(read_pointer_q[2]),
        .I2(read_pointer_q[1]),
        .O(\read_pointer_q[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \read_pointer_q[2]_i_1 
       (.I0(pop_i),
        .I1(\status_cnt_q_reg_n_0_[0] ),
        .I2(\status_cnt_q_reg_n_0_[1] ),
        .I3(status_cnt_q_reg),
        .I4(\status_cnt_q_reg_n_0_[2] ),
        .O(read_pointer_q0));
  (* SOFT_HLUTNM = "soft_lutpair5854" *) 
  LUT3 #(
    .INIT(8'h64)) 
    \read_pointer_q[2]_i_2 
       (.I0(read_pointer_q[0]),
        .I1(read_pointer_q[2]),
        .I2(read_pointer_q[1]),
        .O(\read_pointer_q[2]_i_2_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \read_pointer_q_reg[0] 
       (.C(clk_i),
        .CE(read_pointer_q0),
        .CLR(rst_ni),
        .D(\read_pointer_q[0]_i_1_n_0 ),
        .Q(read_pointer_q[0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \read_pointer_q_reg[1] 
       (.C(clk_i),
        .CE(read_pointer_q0),
        .CLR(rst_ni),
        .D(\read_pointer_q[1]_i_1_n_0 ),
        .Q(read_pointer_q[1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \read_pointer_q_reg[2] 
       (.C(clk_i),
        .CE(read_pointer_q0),
        .CLR(rst_ni),
        .D(\read_pointer_q[2]_i_2_n_0 ),
        .Q(read_pointer_q[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \status_cnt_q[0]_i_1 
       (.I0(\status_cnt_q_reg_n_0_[0] ),
        .O(\status_cnt_q[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5850" *) 
  LUT5 #(
    .INIT(32'h96969694)) 
    \status_cnt_q[1]_i_1 
       (.I0(pop_i),
        .I1(\status_cnt_q_reg_n_0_[0] ),
        .I2(\status_cnt_q_reg_n_0_[1] ),
        .I3(status_cnt_q_reg),
        .I4(\status_cnt_q_reg_n_0_[2] ),
        .O(\status_cnt_q[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5850" *) 
  LUT5 #(
    .INIT(32'hBB44DD20)) 
    \status_cnt_q[2]_i_1 
       (.I0(pop_i),
        .I1(\status_cnt_q_reg_n_0_[0] ),
        .I2(status_cnt_q_reg),
        .I3(\status_cnt_q_reg_n_0_[2] ),
        .I4(\status_cnt_q_reg_n_0_[1] ),
        .O(\status_cnt_q[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h55655557AAAAAAA8)) 
    \status_cnt_q[3]_i_1 
       (.I0(pop_i),
        .I1(\status_cnt_q_reg_n_0_[0] ),
        .I2(\status_cnt_q_reg_n_0_[1] ),
        .I3(status_cnt_q_reg),
        .I4(\status_cnt_q_reg_n_0_[2] ),
        .I5(push_i),
        .O(status_cnt_n));
  LUT5 #(
    .INIT(32'hDF20FB00)) 
    \status_cnt_q[3]_i_2 
       (.I0(\status_cnt_q_reg_n_0_[0] ),
        .I1(pop_i),
        .I2(\status_cnt_q_reg_n_0_[1] ),
        .I3(status_cnt_q_reg),
        .I4(\status_cnt_q_reg_n_0_[2] ),
        .O(\status_cnt_q[3]_i_2_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \status_cnt_q_reg[0] 
       (.C(clk_i),
        .CE(status_cnt_n),
        .CLR(rst_ni),
        .D(\status_cnt_q[0]_i_1_n_0 ),
        .Q(\status_cnt_q_reg_n_0_[0] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \status_cnt_q_reg[1] 
       (.C(clk_i),
        .CE(status_cnt_n),
        .CLR(rst_ni),
        .D(\status_cnt_q[1]_i_1_n_0 ),
        .Q(\status_cnt_q_reg_n_0_[1] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \status_cnt_q_reg[2] 
       (.C(clk_i),
        .CE(status_cnt_n),
        .CLR(rst_ni),
        .D(\status_cnt_q[2]_i_1_n_0 ),
        .Q(\status_cnt_q_reg_n_0_[2] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \status_cnt_q_reg[3] 
       (.C(clk_i),
        .CE(status_cnt_n),
        .CLR(rst_ni),
        .D(\status_cnt_q[3]_i_2_n_0 ),
        .Q(status_cnt_q_reg));
  LUT1 #(
    .INIT(2'h1)) 
    \write_pointer_q[0]_i_1 
       (.I0(write_pointer_q[0]),
        .O(\write_pointer_q[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5855" *) 
  LUT3 #(
    .INIT(8'h26)) 
    \write_pointer_q[1]_i_1 
       (.I0(write_pointer_q[1]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[2]),
        .O(\write_pointer_q[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAA2A)) 
    \write_pointer_q[2]_i_1 
       (.I0(push_i),
        .I1(\status_cnt_q_reg_n_0_[1] ),
        .I2(\status_cnt_q_reg_n_0_[2] ),
        .I3(\status_cnt_q_reg_n_0_[0] ),
        .I4(status_cnt_q_reg),
        .O(write_pointer_q0));
  (* SOFT_HLUTNM = "soft_lutpair5855" *) 
  LUT3 #(
    .INIT(8'h38)) 
    \write_pointer_q[2]_i_2 
       (.I0(write_pointer_q[1]),
        .I1(write_pointer_q[0]),
        .I2(write_pointer_q[2]),
        .O(\write_pointer_q[2]_i_2_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \write_pointer_q_reg[0] 
       (.C(clk_i),
        .CE(write_pointer_q0),
        .CLR(rst_ni),
        .D(\write_pointer_q[0]_i_1_n_0 ),
        .Q(write_pointer_q[0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \write_pointer_q_reg[1] 
       (.C(clk_i),
        .CE(write_pointer_q0),
        .CLR(rst_ni),
        .D(\write_pointer_q[1]_i_1_n_0 ),
        .Q(write_pointer_q[1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \write_pointer_q_reg[2] 
       (.C(clk_i),
        .CE(write_pointer_q0),
        .CLR(rst_ni),
        .D(\write_pointer_q[2]_i_2_n_0 ),
        .Q(write_pointer_q[2]));
endmodule

(* Bypass = "1'b0" *) (* ORIG_REF_NAME = "spill_register" *) 
module spill_register__parameterized12__2
   (clk_i,
    rst_ni,
    valid_i,
    ready_o,
    \data_i[id] ,
    \data_i[resp] ,
    \data_i[user] ,
    valid_o,
    ready_i,
    \data_o[id] ,
    \data_o[resp] ,
    \data_o[user] );
  input clk_i;
  input rst_ni;
  input valid_i;
  output ready_o;
  input [3:0]\data_i[id] ;
  input [1:0]\data_i[resp] ;
  input [1:0]\data_i[user] ;
  output valid_o;
  input ready_i;
  output [3:0]\data_o[id] ;
  output [1:0]\data_o[resp] ;
  output [1:0]\data_o[user] ;

  wire clk_i;
  wire [3:0]\data_i[id] ;
  wire [1:0]\data_i[resp] ;
  wire [3:0]\data_o[id] ;
  wire [1:0]\data_o[resp] ;
  wire ready_i;
  wire ready_o;
  wire rst_ni;
  wire valid_i;
  wire valid_o;
  wire NLW_spill_register_flushable_i_flush_i_UNCONNECTED;
  wire [0:0]\NLW_spill_register_flushable_i_data_i[resp]_UNCONNECTED ;
  wire [1:0]\NLW_spill_register_flushable_i_data_i[user]_UNCONNECTED ;
  wire [0:0]\NLW_spill_register_flushable_i_data_o[resp]_UNCONNECTED ;
  wire [1:0]\NLW_spill_register_flushable_i_data_o[user]_UNCONNECTED ;

  (* Bypass = "1'b0" *) 
  spill_register_flushable__parameterized12__2 spill_register_flushable_i
       (.clk_i(clk_i),
        .\data_i[id] (\data_i[id] ),
        .\data_i[resp] ({\data_i[resp] [1],\NLW_spill_register_flushable_i_data_i[resp]_UNCONNECTED [0]}),
        .\data_i[user] (\NLW_spill_register_flushable_i_data_i[user]_UNCONNECTED [1:0]),
        .\data_o[id] (\data_o[id] ),
        .\data_o[resp] ({\data_o[resp] [1],\NLW_spill_register_flushable_i_data_o[resp]_UNCONNECTED [0]}),
        .\data_o[user] (\NLW_spill_register_flushable_i_data_o[user]_UNCONNECTED [1:0]),
        .flush_i(NLW_spill_register_flushable_i_flush_i_UNCONNECTED),
        .ready_i(ready_i),
        .ready_o(ready_o),
        .rst_ni(rst_ni),
        .valid_i(valid_i),
        .valid_o(valid_o));
endmodule

(* Bypass = "1'b0" *) (* ORIG_REF_NAME = "spill_register_flushable" *) 
module spill_register_flushable__parameterized12__2
   (clk_i,
    rst_ni,
    valid_i,
    flush_i,
    ready_o,
    \data_i[id] ,
    \data_i[resp] ,
    \data_i[user] ,
    valid_o,
    ready_i,
    \data_o[id] ,
    \data_o[resp] ,
    \data_o[user] );
  input clk_i;
  input rst_ni;
  input valid_i;
  input flush_i;
  output ready_o;
  input [3:0]\data_i[id] ;
  input [1:0]\data_i[resp] ;
  input [1:0]\data_i[user] ;
  output valid_o;
  input ready_i;
  output [3:0]\data_o[id] ;
  output [1:0]\data_o[resp] ;
  output [1:0]\data_o[user] ;

  wire clk_i;
  wire [3:0]\data_i[id] ;
  wire [1:0]\data_i[resp] ;
  wire [3:0]\data_o[id] ;
  wire [1:0]\data_o[resp] ;
  wire \gen_spill_reg.a_data_q_reg[id_n_0_][0] ;
  wire \gen_spill_reg.a_data_q_reg[id_n_0_][1] ;
  wire \gen_spill_reg.a_data_q_reg[id_n_0_][2] ;
  wire \gen_spill_reg.a_data_q_reg[id_n_0_][3] ;
  wire \gen_spill_reg.a_data_q_reg[resp_n_0_][1] ;
  wire \gen_spill_reg.a_fill ;
  wire \gen_spill_reg.a_full_q ;
  wire \gen_spill_reg.a_full_q_i_1_n_0 ;
  wire \gen_spill_reg.b_data_q[id][3]_i_1_n_0 ;
  wire \gen_spill_reg.b_data_q_reg[id_n_0_][0] ;
  wire \gen_spill_reg.b_data_q_reg[id_n_0_][1] ;
  wire \gen_spill_reg.b_data_q_reg[id_n_0_][2] ;
  wire \gen_spill_reg.b_data_q_reg[id_n_0_][3] ;
  wire \gen_spill_reg.b_data_q_reg[resp_n_0_][1] ;
  wire \gen_spill_reg.b_full_q ;
  wire \gen_spill_reg.b_full_q_i_1_n_0 ;
  wire ready_i;
  wire ready_o;
  wire rst_ni;
  wire valid_i;
  wire valid_o;

  LUT3 #(
    .INIT(8'hB8)) 
    \data_o[id][0]_INST_0 
       (.I0(\gen_spill_reg.b_data_q_reg[id_n_0_][0] ),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_data_q_reg[id_n_0_][0] ),
        .O(\data_o[id] [0]));
  LUT3 #(
    .INIT(8'hB8)) 
    \data_o[id][1]_INST_0 
       (.I0(\gen_spill_reg.b_data_q_reg[id_n_0_][1] ),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_data_q_reg[id_n_0_][1] ),
        .O(\data_o[id] [1]));
  LUT3 #(
    .INIT(8'hB8)) 
    \data_o[id][2]_INST_0 
       (.I0(\gen_spill_reg.b_data_q_reg[id_n_0_][2] ),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_data_q_reg[id_n_0_][2] ),
        .O(\data_o[id] [2]));
  LUT3 #(
    .INIT(8'hB8)) 
    \data_o[id][3]_INST_0 
       (.I0(\gen_spill_reg.b_data_q_reg[id_n_0_][3] ),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_data_q_reg[id_n_0_][3] ),
        .O(\data_o[id] [3]));
  LUT3 #(
    .INIT(8'hB8)) 
    \data_o[resp][1]_INST_0 
       (.I0(\gen_spill_reg.b_data_q_reg[resp_n_0_][1] ),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_data_q_reg[resp_n_0_][1] ),
        .O(\data_o[resp] [1]));
  LUT3 #(
    .INIT(8'h2A)) 
    \gen_spill_reg.a_data_q[id][3]_i_1 
       (.I0(valid_i),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_full_q ),
        .O(\gen_spill_reg.a_fill ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_data_q_reg[id][0] 
       (.C(clk_i),
        .CE(\gen_spill_reg.a_fill ),
        .CLR(rst_ni),
        .D(\data_i[id] [0]),
        .Q(\gen_spill_reg.a_data_q_reg[id_n_0_][0] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_data_q_reg[id][1] 
       (.C(clk_i),
        .CE(\gen_spill_reg.a_fill ),
        .CLR(rst_ni),
        .D(\data_i[id] [1]),
        .Q(\gen_spill_reg.a_data_q_reg[id_n_0_][1] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_data_q_reg[id][2] 
       (.C(clk_i),
        .CE(\gen_spill_reg.a_fill ),
        .CLR(rst_ni),
        .D(\data_i[id] [2]),
        .Q(\gen_spill_reg.a_data_q_reg[id_n_0_][2] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_data_q_reg[id][3] 
       (.C(clk_i),
        .CE(\gen_spill_reg.a_fill ),
        .CLR(rst_ni),
        .D(\data_i[id] [3]),
        .Q(\gen_spill_reg.a_data_q_reg[id_n_0_][3] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_data_q_reg[resp][1] 
       (.C(clk_i),
        .CE(\gen_spill_reg.a_fill ),
        .CLR(rst_ni),
        .D(\data_i[resp] [1]),
        .Q(\gen_spill_reg.a_data_q_reg[resp_n_0_][1] ));
  LUT3 #(
    .INIT(8'hEA)) 
    \gen_spill_reg.a_full_q_i_1 
       (.I0(valid_i),
        .I1(\gen_spill_reg.b_full_q ),
        .I2(\gen_spill_reg.a_full_q ),
        .O(\gen_spill_reg.a_full_q_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.a_full_q_reg 
       (.C(clk_i),
        .CE(1'b1),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_full_q_i_1_n_0 ),
        .Q(\gen_spill_reg.a_full_q ));
  LUT3 #(
    .INIT(8'h04)) 
    \gen_spill_reg.b_data_q[id][3]_i_1 
       (.I0(\gen_spill_reg.b_full_q ),
        .I1(\gen_spill_reg.a_full_q ),
        .I2(ready_i),
        .O(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_data_q_reg[id][0] 
       (.C(clk_i),
        .CE(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_data_q_reg[id_n_0_][0] ),
        .Q(\gen_spill_reg.b_data_q_reg[id_n_0_][0] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_data_q_reg[id][1] 
       (.C(clk_i),
        .CE(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_data_q_reg[id_n_0_][1] ),
        .Q(\gen_spill_reg.b_data_q_reg[id_n_0_][1] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_data_q_reg[id][2] 
       (.C(clk_i),
        .CE(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_data_q_reg[id_n_0_][2] ),
        .Q(\gen_spill_reg.b_data_q_reg[id_n_0_][2] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_data_q_reg[id][3] 
       (.C(clk_i),
        .CE(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_data_q_reg[id_n_0_][3] ),
        .Q(\gen_spill_reg.b_data_q_reg[id_n_0_][3] ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_data_q_reg[resp][1] 
       (.C(clk_i),
        .CE(\gen_spill_reg.b_data_q[id][3]_i_1_n_0 ),
        .CLR(rst_ni),
        .D(\gen_spill_reg.a_data_q_reg[resp_n_0_][1] ),
        .Q(\gen_spill_reg.b_data_q_reg[resp_n_0_][1] ));
  LUT3 #(
    .INIT(8'h32)) 
    \gen_spill_reg.b_full_q_i_1 
       (.I0(\gen_spill_reg.a_full_q ),
        .I1(ready_i),
        .I2(\gen_spill_reg.b_full_q ),
        .O(\gen_spill_reg.b_full_q_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  FDCE #(
    .INIT(1'b0),
    .IS_CLR_INVERTED(1'b1)) 
    \gen_spill_reg.b_full_q_reg 
       (.C(clk_i),
        .CE(1'b1),
        .CLR(rst_ni),
        .D(\gen_spill_reg.b_full_q_i_1_n_0 ),
        .Q(\gen_spill_reg.b_full_q ));
  LUT2 #(
    .INIT(4'h7)) 
    ready_o_INST_0
       (.I0(\gen_spill_reg.a_full_q ),
        .I1(\gen_spill_reg.b_full_q ),
        .O(ready_o));
  LUT2 #(
    .INIT(4'hE)) 
    valid_o_INST_0
       (.I0(\gen_spill_reg.a_full_q ),
        .I1(\gen_spill_reg.b_full_q ),
        .O(valid_o));
endmodule

(* ADDR_DEPTH = "32'b00000000000000000000000000000011" *) (* DATA_WIDTH = "32'b00000000000000000000000000100000" *) (* DEPTH = "6" *) 
(* FALL_THROUGH = "1'b0" *) (* ORIG_REF_NAME = "stream_fifo" *) 
module stream_fifo__parameterized1
   (clk_i,
    rst_ni,
    flush_i,
    testmode_i,
    usage_o,
    \data_i[data] ,
    \data_i[strb] ,
    \data_i[last] ,
    \data_i[user] ,
    valid_i,
    ready_o,
    \data_o[data] ,
    \data_o[strb] ,
    \data_o[last] ,
    \data_o[user] ,
    valid_o,
    ready_i);
  input clk_i;
  input rst_ni;
  input flush_i;
  input testmode_i;
  output [2:0]usage_o;
  input [63:0]\data_i[data] ;
  input [7:0]\data_i[strb] ;
  input \data_i[last] ;
  input [1:0]\data_i[user] ;
  input valid_i;
  output ready_o;
  output [63:0]\data_o[data] ;
  output [7:0]\data_o[strb] ;
  output \data_o[last] ;
  output [1:0]\data_o[user] ;
  output valid_o;
  input ready_i;

  wire clk_i;
  wire [63:0]\data_i[data] ;
  wire [7:0]\data_i[strb] ;
  wire [63:0]\data_o[data] ;
  wire [7:0]\data_o[strb] ;
  wire fifo_i_i_1_n_0;
  wire fifo_i_i_2_n_0;
  wire ready_i;
  wire ready_o;
  wire rst_ni;
  wire valid_i;
  wire valid_o;
  wire \NLW_fifo_i_data_i[last]_UNCONNECTED ;
  wire \NLW_fifo_i_data_o[last]_UNCONNECTED ;
  wire NLW_fifo_i_flush_i_UNCONNECTED;
  wire NLW_fifo_i_testmode_i_UNCONNECTED;
  wire [1:0]\NLW_fifo_i_data_i[user]_UNCONNECTED ;
  wire [1:0]\NLW_fifo_i_data_o[user]_UNCONNECTED ;
  wire [2:0]NLW_fifo_i_usage_o_UNCONNECTED;

  (* ADDR_DEPTH = "32'b00000000000000000000000000000011" *) 
  (* DATA_WIDTH = "32'b00000000000000000000000000100000" *) 
  (* DEPTH = "6" *) 
  (* FALL_THROUGH = "1'b0" *) 
  (* FifoDepth = "6" *) 
  fifo_v3__parameterized13 fifo_i
       (.clk_i(clk_i),
        .\data_i[data] (\data_i[data] ),
        .\data_i[last] (\NLW_fifo_i_data_i[last]_UNCONNECTED ),
        .\data_i[strb] (\data_i[strb] ),
        .\data_i[user] (\NLW_fifo_i_data_i[user]_UNCONNECTED [1:0]),
        .\data_o[data] (\data_o[data] ),
        .\data_o[last] (\NLW_fifo_i_data_o[last]_UNCONNECTED ),
        .\data_o[strb] (\data_o[strb] ),
        .\data_o[user] (\NLW_fifo_i_data_o[user]_UNCONNECTED [1:0]),
        .empty_o(valid_o),
        .flush_i(NLW_fifo_i_flush_i_UNCONNECTED),
        .full_o(ready_o),
        .pop_i(fifo_i_i_2_n_0),
        .push_i(fifo_i_i_1_n_0),
        .rst_ni(rst_ni),
        .testmode_i(NLW_fifo_i_testmode_i_UNCONNECTED),
        .usage_o(NLW_fifo_i_usage_o_UNCONNECTED[2:0]));
  (* OPT_MODIFIED = "RETARGET" *) 
  (* SOFT_HLUTNM = "soft_lutpair5857" *) 
  LUT2 #(
    .INIT(4'h8)) 
    fifo_i_i_1
       (.I0(valid_i),
        .I1(ready_o),
        .O(fifo_i_i_1_n_0));
  (* OPT_MODIFIED = "RETARGET" *) 
  (* SOFT_HLUTNM = "soft_lutpair5856" *) 
  LUT2 #(
    .INIT(4'h8)) 
    fifo_i_i_2
       (.I0(ready_i),
        .I1(valid_o),
        .O(fifo_i_i_2_n_0));
endmodule
///////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 1995/2016 Xilinx, Inc.
//  All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /     Vendor      : Xilinx
// \   \   \/      Version     : 2016.4
//  \   \          Description : Xilinx Unified Simulation Library Component
//  /   /                        Fast Carry Logic with Look Ahead
// /___/   /\      Filename    : CARRY8.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision
//    09/26/12 - Initial functional version.
//    05/24/13 - Add CARRY_TYPE, CI_TOP
//    10/22/14 - 808642 - Added #1 to $finish
//  End Revision
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps / 1 ps

`celldefine

module CARRY8 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter CARRY_TYPE = "SINGLE_CY8"
)(
  output [7:0] CO,
  output [7:0] O,

  input CI,
  input CI_TOP,
  input [7:0] DI,
  input [7:0] S
);
  
// define constants
  localparam MODULE_NAME = "CARRY8";

// Parameter encodings and registers
  localparam CARRY_TYPE_DUAL_CY4 = 1;
  localparam CARRY_TYPE_SINGLE_CY8 = 0;

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "CARRY8_dr.v"
`else
  reg [80:1] CARRY_TYPE_REG = CARRY_TYPE;
`endif

`ifdef XIL_XECLIB
  wire CARRY_TYPE_BIN;
`else
  reg CARRY_TYPE_BIN;
`endif

`ifdef XIL_ATTR_TEST
  reg attr_test = 1'b1;
`else
  reg attr_test = 1'b0;
`endif
  reg attr_err = 1'b0;

  wire CI_TOP_in;
  wire CI_in;
  wire [7:0] DI_in;
  wire [7:0] S_in;


  assign CI_TOP_in = ((CI_TOP !== 1'bz) &&
                      ((CARRY_TYPE_BIN == CARRY_TYPE_DUAL_CY4) && CI_TOP)) ||
                     ((CARRY_TYPE_BIN == CARRY_TYPE_SINGLE_CY8) && CO[3]); // rv 0
  assign CI_in = (CI !== 1'bz) && CI; // rv 0
  assign DI_in[7] = (DI[7] !== 1'bz) && DI[7]; // rv 0
  assign DI_in[6] = (DI[6] !== 1'bz) && DI[6]; // rv 0
  assign DI_in[5] = (DI[5] !== 1'bz) && DI[5]; // rv 0
  assign DI_in[4] = (DI[4] !== 1'bz) && DI[4]; // rv 0
  assign DI_in[3] = (DI[3] !== 1'bz) && DI[3]; // rv 0
  assign DI_in[2] = (DI[2] !== 1'bz) && DI[2]; // rv 0
  assign DI_in[1] = (DI[1] !== 1'bz) && DI[1]; // rv 0
  assign DI_in[0] = (DI[0] !== 1'bz) && DI[0]; // rv 0
  assign S_in[7] = (S[7] !== 1'bz) && S[7]; // rv 0
  assign S_in[6] = (S[6] !== 1'bz) && S[6]; // rv 0
  assign S_in[5] = (S[5] !== 1'bz) && S[5]; // rv 0
  assign S_in[4] = (S[4] !== 1'bz) && S[4]; // rv 0
  assign S_in[3] = (S[3] !== 1'bz) && S[3]; // rv 0
  assign S_in[2] = (S[2] !== 1'bz) && S[2]; // rv 0
  assign S_in[1] = (S[1] !== 1'bz) && S[1]; // rv 0
  assign S_in[0] = (S[0] !== 1'bz) && S[0]; // rv 0

`ifndef XIL_XECLIB
  initial begin
    #1;
    trig_attr = ~trig_attr;
  end
`endif

`ifdef XIL_XECLIB
  assign CARRY_TYPE_BIN =
    (CARRY_TYPE_REG == "SINGLE_CY8") ? CARRY_TYPE_SINGLE_CY8 :
    (CARRY_TYPE_REG == "DUAL_CY4") ? CARRY_TYPE_DUAL_CY4 :
     CARRY_TYPE_SINGLE_CY8;

`else
  always @(trig_attr) begin
  #1;
  CARRY_TYPE_BIN =
    (CARRY_TYPE_REG == "SINGLE_CY8") ? CARRY_TYPE_SINGLE_CY8 :
    (CARRY_TYPE_REG == "DUAL_CY4") ? CARRY_TYPE_DUAL_CY4 :
     CARRY_TYPE_SINGLE_CY8;

  end
`endif

`ifndef XIL_XECLIB
always @ (trig_attr) begin
  #1;
    if ((attr_test == 1'b1) ||
        ((CARRY_TYPE_REG != "SINGLE_CY8") &&
         (CARRY_TYPE_REG != "DUAL_CY4"))) begin
      $display("Error: [Unisim %s-101] CARRY_TYPE attribute is set to %s.  Legal values for this attribute are SINGLE_CY8 or DUAL_CY4. Instance: %m", MODULE_NAME, CARRY_TYPE_REG);
      attr_err = 1'b1;
    end

    if (attr_err == 1'b1) #1 $finish;
  end
`endif

  wire [7:0] CO_fb;
  assign CO_fb = {CO[6:4], CI_TOP_in, CO[2:0], CI_in};
  assign O = S_in ^ CO_fb;
  assign CO = (S_in & CO_fb) | (~S_in & DI_in);

`ifndef XIL_XECLIB
`ifdef XIL_TIMING
  specify
    (CI => CO[0]) = (0:0:0, 0:0:0);
    (CI => CO[1]) = (0:0:0, 0:0:0);
    (CI => CO[2]) = (0:0:0, 0:0:0);
    (CI => CO[3]) = (0:0:0, 0:0:0);
    (CI => CO[4]) = (0:0:0, 0:0:0);
    (CI => CO[5]) = (0:0:0, 0:0:0);
    (CI => CO[6]) = (0:0:0, 0:0:0);
    (CI => CO[7]) = (0:0:0, 0:0:0);
    (CI => O[0]) = (0:0:0, 0:0:0);
    (CI => O[1]) = (0:0:0, 0:0:0);
    (CI => O[2]) = (0:0:0, 0:0:0);
    (CI => O[3]) = (0:0:0, 0:0:0);
    (CI => O[4]) = (0:0:0, 0:0:0);
    (CI => O[5]) = (0:0:0, 0:0:0);
    (CI => O[6]) = (0:0:0, 0:0:0);
    (CI => O[7]) = (0:0:0, 0:0:0);
    (CI_TOP => CO[4]) = (0:0:0, 0:0:0);
    (CI_TOP => CO[5]) = (0:0:0, 0:0:0);
    (CI_TOP => CO[6]) = (0:0:0, 0:0:0);
    (CI_TOP => CO[7]) = (0:0:0, 0:0:0);
    (CI_TOP => O[4]) = (0:0:0, 0:0:0);
    (CI_TOP => O[5]) = (0:0:0, 0:0:0);
    (CI_TOP => O[6]) = (0:0:0, 0:0:0);
    (CI_TOP => O[7]) = (0:0:0, 0:0:0);
    (DI[0] => CO[0]) = (0:0:0, 0:0:0);
    (DI[0] => CO[1]) = (0:0:0, 0:0:0);
    (DI[0] => CO[2]) = (0:0:0, 0:0:0);
    (DI[0] => CO[3]) = (0:0:0, 0:0:0);
    (DI[0] => CO[4]) = (0:0:0, 0:0:0);
    (DI[0] => CO[5]) = (0:0:0, 0:0:0);
    (DI[0] => CO[6]) = (0:0:0, 0:0:0);
    (DI[0] => CO[7]) = (0:0:0, 0:0:0);
    (DI[0] => O[0]) = (0:0:0, 0:0:0);
    (DI[0] => O[1]) = (0:0:0, 0:0:0);
    (DI[0] => O[2]) = (0:0:0, 0:0:0);
    (DI[0] => O[3]) = (0:0:0, 0:0:0);
    (DI[0] => O[4]) = (0:0:0, 0:0:0);
    (DI[0] => O[5]) = (0:0:0, 0:0:0);
    (DI[0] => O[6]) = (0:0:0, 0:0:0);
    (DI[0] => O[7]) = (0:0:0, 0:0:0);
    (DI[1] => CO[1]) = (0:0:0, 0:0:0);
    (DI[1] => CO[2]) = (0:0:0, 0:0:0);
    (DI[1] => CO[3]) = (0:0:0, 0:0:0);
    (DI[1] => CO[4]) = (0:0:0, 0:0:0);
    (DI[1] => CO[5]) = (0:0:0, 0:0:0);
    (DI[1] => CO[6]) = (0:0:0, 0:0:0);
    (DI[1] => CO[7]) = (0:0:0, 0:0:0);
    (DI[1] => O[2]) = (0:0:0, 0:0:0);
    (DI[1] => O[3]) = (0:0:0, 0:0:0);
    (DI[1] => O[4]) = (0:0:0, 0:0:0);
    (DI[1] => O[5]) = (0:0:0, 0:0:0);
    (DI[1] => O[6]) = (0:0:0, 0:0:0);
    (DI[1] => O[7]) = (0:0:0, 0:0:0);
    (DI[2] => CO[2]) = (0:0:0, 0:0:0);
    (DI[2] => CO[3]) = (0:0:0, 0:0:0);
    (DI[2] => CO[4]) = (0:0:0, 0:0:0);
    (DI[2] => CO[5]) = (0:0:0, 0:0:0);
    (DI[2] => CO[6]) = (0:0:0, 0:0:0);
    (DI[2] => CO[7]) = (0:0:0, 0:0:0);
    (DI[2] => O[3]) = (0:0:0, 0:0:0);
    (DI[2] => O[4]) = (0:0:0, 0:0:0);
    (DI[2] => O[5]) = (0:0:0, 0:0:0);
    (DI[2] => O[6]) = (0:0:0, 0:0:0);
    (DI[2] => O[7]) = (0:0:0, 0:0:0);
    (DI[3] => CO[3]) = (0:0:0, 0:0:0);
    (DI[3] => CO[4]) = (0:0:0, 0:0:0);
    (DI[3] => CO[5]) = (0:0:0, 0:0:0);
    (DI[3] => CO[6]) = (0:0:0, 0:0:0);
    (DI[3] => CO[7]) = (0:0:0, 0:0:0);
    (DI[3] => O[4]) = (0:0:0, 0:0:0);
    (DI[3] => O[5]) = (0:0:0, 0:0:0);
    (DI[3] => O[6]) = (0:0:0, 0:0:0);
    (DI[3] => O[7]) = (0:0:0, 0:0:0);
    (DI[4] => CO[4]) = (0:0:0, 0:0:0);
    (DI[4] => CO[5]) = (0:0:0, 0:0:0);
    (DI[4] => CO[6]) = (0:0:0, 0:0:0);
    (DI[4] => CO[7]) = (0:0:0, 0:0:0);
    (DI[4] => O[5]) = (0:0:0, 0:0:0);
    (DI[4] => O[6]) = (0:0:0, 0:0:0);
    (DI[4] => O[7]) = (0:0:0, 0:0:0);
    (DI[5] => CO[5]) = (0:0:0, 0:0:0);
    (DI[5] => CO[6]) = (0:0:0, 0:0:0);
    (DI[5] => CO[7]) = (0:0:0, 0:0:0);
    (DI[5] => O[6]) = (0:0:0, 0:0:0);
    (DI[5] => O[7]) = (0:0:0, 0:0:0);
    (DI[6] => CO[6]) = (0:0:0, 0:0:0);
    (DI[6] => CO[7]) = (0:0:0, 0:0:0);
    (DI[6] => O[7]) = (0:0:0, 0:0:0);
    (DI[7] => CO[7]) = (0:0:0, 0:0:0);
    (S[0] => CO[0]) = (0:0:0, 0:0:0);
    (S[0] => CO[1]) = (0:0:0, 0:0:0);
    (S[0] => CO[2]) = (0:0:0, 0:0:0);
    (S[0] => CO[3]) = (0:0:0, 0:0:0);
    (S[0] => CO[4]) = (0:0:0, 0:0:0);
    (S[0] => CO[5]) = (0:0:0, 0:0:0);
    (S[0] => CO[6]) = (0:0:0, 0:0:0);
    (S[0] => CO[7]) = (0:0:0, 0:0:0);
    (S[0] => O[0]) = (0:0:0, 0:0:0);
    (S[0] => O[1]) = (0:0:0, 0:0:0);
    (S[0] => O[2]) = (0:0:0, 0:0:0);
    (S[0] => O[3]) = (0:0:0, 0:0:0);
    (S[0] => O[4]) = (0:0:0, 0:0:0);
    (S[0] => O[5]) = (0:0:0, 0:0:0);
    (S[0] => O[6]) = (0:0:0, 0:0:0);
    (S[0] => O[7]) = (0:0:0, 0:0:0);
    (S[1] => CO[1]) = (0:0:0, 0:0:0);
    (S[1] => CO[2]) = (0:0:0, 0:0:0);
    (S[1] => CO[3]) = (0:0:0, 0:0:0);
    (S[1] => CO[4]) = (0:0:0, 0:0:0);
    (S[1] => CO[5]) = (0:0:0, 0:0:0);
    (S[1] => CO[6]) = (0:0:0, 0:0:0);
    (S[1] => CO[7]) = (0:0:0, 0:0:0);
    (S[1] => O[1]) = (0:0:0, 0:0:0);
    (S[1] => O[2]) = (0:0:0, 0:0:0);
    (S[1] => O[3]) = (0:0:0, 0:0:0);
    (S[1] => O[4]) = (0:0:0, 0:0:0);
    (S[1] => O[5]) = (0:0:0, 0:0:0);
    (S[1] => O[6]) = (0:0:0, 0:0:0);
    (S[1] => O[7]) = (0:0:0, 0:0:0);
    (S[2] => CO[2]) = (0:0:0, 0:0:0);
    (S[2] => CO[3]) = (0:0:0, 0:0:0);
    (S[2] => CO[4]) = (0:0:0, 0:0:0);
    (S[2] => CO[5]) = (0:0:0, 0:0:0);
    (S[2] => CO[6]) = (0:0:0, 0:0:0);
    (S[2] => CO[7]) = (0:0:0, 0:0:0);
    (S[2] => O[2]) = (0:0:0, 0:0:0);
    (S[2] => O[3]) = (0:0:0, 0:0:0);
    (S[2] => O[4]) = (0:0:0, 0:0:0);
    (S[2] => O[5]) = (0:0:0, 0:0:0);
    (S[2] => O[6]) = (0:0:0, 0:0:0);
    (S[2] => O[7]) = (0:0:0, 0:0:0);
    (S[3] => CO[3]) = (0:0:0, 0:0:0);
    (S[3] => CO[4]) = (0:0:0, 0:0:0);
    (S[3] => CO[5]) = (0:0:0, 0:0:0);
    (S[3] => CO[6]) = (0:0:0, 0:0:0);
    (S[3] => CO[7]) = (0:0:0, 0:0:0);
    (S[3] => O[3]) = (0:0:0, 0:0:0);
    (S[3] => O[4]) = (0:0:0, 0:0:0);
    (S[3] => O[5]) = (0:0:0, 0:0:0);
    (S[3] => O[6]) = (0:0:0, 0:0:0);
    (S[3] => O[7]) = (0:0:0, 0:0:0);
    (S[4] => CO[4]) = (0:0:0, 0:0:0);
    (S[4] => CO[5]) = (0:0:0, 0:0:0);
    (S[4] => CO[6]) = (0:0:0, 0:0:0);
    (S[4] => CO[7]) = (0:0:0, 0:0:0);
    (S[4] => O[4]) = (0:0:0, 0:0:0);
    (S[4] => O[5]) = (0:0:0, 0:0:0);
    (S[4] => O[6]) = (0:0:0, 0:0:0);
    (S[4] => O[7]) = (0:0:0, 0:0:0);
    (S[5] => CO[5]) = (0:0:0, 0:0:0);
    (S[5] => CO[6]) = (0:0:0, 0:0:0);
    (S[5] => CO[7]) = (0:0:0, 0:0:0);
    (S[5] => O[5]) = (0:0:0, 0:0:0);
    (S[5] => O[6]) = (0:0:0, 0:0:0);
    (S[5] => O[7]) = (0:0:0, 0:0:0);
    (S[6] => CO[6]) = (0:0:0, 0:0:0);
    (S[6] => CO[7]) = (0:0:0, 0:0:0);
    (S[6] => O[6]) = (0:0:0, 0:0:0);
    (S[6] => O[7]) = (0:0:0, 0:0:0);
    (S[7] => CO[7]) = (0:0:0, 0:0:0);
    (S[7] => O[7]) = (0:0:0, 0:0:0);
    specparam PATHPULSE$ = 0;
  endspecify
`endif
`endif

endmodule

`endcelldefine

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  1-Bit Look-Up Table
// /___/   /\     Filename : LUT1.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    05/12/11 - Initial version.
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT1 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [1:0] INIT = 2'h0
)(
  output O,

  input I0
);

// define constants
  localparam MODULE_NAME = "LUT1";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT1_dr.v"
`else
  reg [1:0] INIT_REG = INIT;
`endif

  x_lut1_mux2 (O, INIT_REG[1], INIT_REG[0], I0);

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

primitive x_lut1_mux2 (o, d1, d0, s0);

  output o;
  input  d1, d0;
  input  s0;

  table

    //         d1  d0      s0 : o;

               ?   1       0  : 1;
               ?   0       0  : 0;
               1   ?       1  : 1;
               0   ?       1  : 0;

               0   0       x  : 0;
               1   1       x  : 1;

  endtable

endprimitive

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  4-Bit Look-Up Table
// /___/   /\     Filename : LUT4.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    03/23/04 - Initial version.
//    02/04/05 - Replace primitive with function; Remove buf.
//    03/11/05 - Add LOC Parameter
//    06/04/07 - Add wire declaration to internal signal.
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT4 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [15:0] INIT = 16'h0000
)(
  output O,

  input I0,
  input I1,
  input I2,
  input I3
);

// define constants
  localparam MODULE_NAME = "LUT4";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT4_dr.v"
`else
  reg [15:0] INIT_REG = INIT;
`endif

// begin behavioral model

  reg O_out;

  assign O = O_out;

  function lut_mux4_f;
  input [3:0] d;
  input [1:0] s;
  begin
    if (((s[1]^s[0]) === 1'b1) || ((s[1]^s[0]) === 1'b0))
      lut_mux4_f = d[s];
    else if ( ~(|d) || &d)
      lut_mux4_f = d[0];
    else if (((s[0] === 1'b1) || (s[0] === 1'b0)) && (d[{1'b0,s[0]}] === d[{1'b1,s[0]}]))
      lut_mux4_f = d[{1'b0,s[0]}];
    else if (((s[1] === 1'b1) || (s[1] === 1'b0)) && (d[{s[1],1'b0}] === d[{s[1],1'b1}]))
      lut_mux4_f = d[{s[1],1'b0}];
    else
      lut_mux4_f = 1'bx;
  end
  endfunction

 always @(I0 or I1 or I2 or I3)  begin
   if ( (I0 ^ I1  ^ I2 ^ I3) === 1'b0 || (I0 ^ I1  ^ I2 ^ I3) === 1'b1)
    O_out = INIT_REG[{I3, I2, I1, I0}];
   else if ( ~(|INIT_REG) || &INIT_REG )
    O_out = INIT_REG[0];
   else
    O_out = lut_mux4_f ({lut_mux4_f (INIT_REG[15:12], {I1, I0}),
                     lut_mux4_f ( INIT_REG[11:8], {I1, I0}),
                     lut_mux4_f (  INIT_REG[7:4], {I1, I0}),
                     lut_mux4_f (  INIT_REG[3:0], {I1, I0})}, {I3, I2});
  end

// end behavioral model

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	(I1 => O) = (0:0:0, 0:0:0);
	(I2 => O) = (0:0:0, 0:0:0);
	(I3 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  3-Bit Look-Up Table
// /___/   /\     Filename : LUT3.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    03/23/04 - Initial version.
//    03/11/05 - Add LOC Parameter
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT3 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [7:0] INIT = 8'h00
)(
  output O,

  input I0,
  input I1,
  input I2
);

// define constants
  localparam MODULE_NAME = "LUT3";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT3_dr.v"
`else
  reg [7:0] INIT_REG = INIT;
`endif

  x_lut3_mux8 (O, INIT_REG[7], INIT_REG[6], INIT_REG[5], INIT_REG[4], INIT_REG[3], INIT_REG[2], INIT_REG[1], INIT_REG[0], I2, I1, I0);

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	(I1 => O) = (0:0:0, 0:0:0);
	(I2 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

primitive x_lut3_mux8 (o, d7, d6, d5, d4, d3, d2, d1, d0, s2, s1, s0);

  output o;
  input d7, d6, d5, d4, d3, d2, d1, d0;
  input s2, s1, s0;

  table

    // d7  d6  d5  d4  d3  d2  d1  d0  s2  s1  s0 : o;

       ?   ?   ?   ?   ?   ?   ?   1   0   0   0  : 1;
       ?   ?   ?   ?   ?   ?   ?   0   0   0   0  : 0;
       ?   ?   ?   ?   ?   ?   1   ?   0   0   1  : 1;
       ?   ?   ?   ?   ?   ?   0   ?   0   0   1  : 0;
       ?   ?   ?   ?   ?   1   ?   ?   0   1   0  : 1;
       ?   ?   ?   ?   ?   0   ?   ?   0   1   0  : 0;
       ?   ?   ?   ?   1   ?   ?   ?   0   1   1  : 1;
       ?   ?   ?   ?   0   ?   ?   ?   0   1   1  : 0;
       ?   ?   ?   1   ?   ?   ?   ?   1   0   0  : 1;
       ?   ?   ?   0   ?   ?   ?   ?   1   0   0  : 0;
       ?   ?   1   ?   ?   ?   ?   ?   1   0   1  : 1;
       ?   ?   0   ?   ?   ?   ?   ?   1   0   1  : 0;
       ?   1   ?   ?   ?   ?   ?   ?   1   1   0  : 1;
       ?   0   ?   ?   ?   ?   ?   ?   1   1   0  : 0;
       1   ?   ?   ?   ?   ?   ?   ?   1   1   1  : 1;
       0   ?   ?   ?   ?   ?   ?   ?   1   1   1  : 0;

       ?   ?   ?   ?   ?   ?   0   0   0   0   x  : 0;
       ?   ?   ?   ?   ?   ?   1   1   0   0   x  : 1;
       ?   ?   ?   ?   0   0   ?   ?   0   1   x  : 0;
       ?   ?   ?   ?   1   1   ?   ?   0   1   x  : 1;
       ?   ?   0   0   ?   ?   ?   ?   1   0   x  : 0;
       ?   ?   1   1   ?   ?   ?   ?   1   0   x  : 1;
       0   0   ?   ?   ?   ?   ?   ?   1   1   x  : 0;
       1   1   ?   ?   ?   ?   ?   ?   1   1   x  : 1;

       ?   ?   ?   ?   ?   0   ?   0   0   x   0  : 0;
       ?   ?   ?   ?   ?   1   ?   1   0   x   0  : 1;
       ?   ?   ?   ?   0   ?   0   ?   0   x   1  : 0;
       ?   ?   ?   ?   1   ?   1   ?   0   x   1  : 1;
       ?   0   ?   0   ?   ?   ?   ?   1   x   0  : 0;
       ?   1   ?   1   ?   ?   ?   ?   1   x   0  : 1;
       0   ?   0   ?   ?   ?   ?   ?   1   x   1  : 0;
       1   ?   1   ?   ?   ?   ?   ?   1   x   1  : 1;

       ?   ?   ?   0   ?   ?   ?   0   x   0   0  : 0;
       ?   ?   ?   1   ?   ?   ?   1   x   0   0  : 1;
       ?   ?   0   ?   ?   ?   0   ?   x   0   1  : 0;
       ?   ?   1   ?   ?   ?   1   ?   x   0   1  : 1;
       ?   0   ?   ?   ?   0   ?   ?   x   1   0  : 0;
       ?   1   ?   ?   ?   1   ?   ?   x   1   0  : 1;
       0   ?   ?   ?   0   ?   ?   ?   x   1   1  : 0;
       1   ?   ?   ?   1   ?   ?   ?   x   1   1  : 1;

       ?   ?   ?   ?   0   0   0   0   0   x   x  : 0;
       ?   ?   ?   ?   1   1   1   1   0   x   x  : 1;
       0   0   0   0   ?   ?   ?   ?   1   x   x  : 0;
       1   1   1   1   ?   ?   ?   ?   1   x   x  : 1;

       ?   ?   0   0   ?   ?   0   0   x   0   x  : 0;
       ?   ?   1   1   ?   ?   1   1   x   0   x  : 1;
       0   0   ?   ?   0   0   ?   ?   x   1   x  : 0;
       1   1   ?   ?   1   1   ?   ?   x   1   x  : 1;

       ?   0   ?   0   ?   0   ?   0   x   x   0  : 0;
       ?   1   ?   1   ?   1   ?   1   x   x   0  : 1;
       0   ?   0   ?   0   ?   0   ?   x   x   1  : 0;
       1   ?   1   ?   1   ?   1   ?   x   x   1  : 1;

       0   0   0   0   0   0   0   0   x   x   x  : 0;
       1   1   1   1   1   1   1   1   x   x   x  : 1;

  endtable

endprimitive

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor : Xilinx
// \   \   \/     Version : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  D Flip-Flop with Clock Enable and Asynchronous Clear
// /___/   /\     Filename : FDCE.v
// \   \  /  \
//  \___\/\___\
//
// Revision:
//    08/24/10 - Initial version.
//    10/20/10 - remove unused pin line from table.
//    11/01/11 - Disable timing check when set reset active (CR632017)
//    12/08/11 - add MSGON and XON attributes (CR636891)
//    01/16/12 - 640813 - add MSGON and XON functionality
//    04/16/13 - PR683925 - add invertible pin support.
// End Revision

`timescale  1 ps / 1 ps

`celldefine 

module FDCE #(
  `ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
  parameter MSGON = "TRUE",
  parameter XON = "TRUE",
  `endif
  parameter [0:0] INIT = 1'b0,
  parameter [0:0] IS_CLR_INVERTED = 1'b0,
  parameter [0:0] IS_C_INVERTED = 1'b0,
  parameter [0:0] IS_D_INVERTED = 1'b0
)(
  output Q,
  
  input C,
  input CE,
  input CLR,
  input D
);

    reg [0:0] IS_CLR_INVERTED_REG = IS_CLR_INVERTED;
    reg [0:0] IS_C_INVERTED_REG = IS_C_INVERTED;
    reg [0:0] IS_D_INVERTED_REG = IS_D_INVERTED;
    
    tri0 glblGSR = glbl.GSR;

`ifdef XIL_TIMING
    wire D_dly, C_dly, CE_dly;
    wire CLR_dly;
`endif

    wire CLR_in;

`ifdef XIL_TIMING
    assign CLR_in = (CLR_dly ^ IS_CLR_INVERTED_REG) && (CLR !== 1'bz);
`else
    assign CLR_in = (CLR ^ IS_CLR_INVERTED_REG) && (CLR !== 1'bz);
`endif

// begin behavioral model

  reg Q_out;

  assign #100 Q = Q_out;

    always @(glblGSR or CLR_in)
      if (glblGSR) 
        assign Q_out = INIT;
      else if (CLR_in === 1'b1) 
        assign Q_out = 1'b0;
      else if (CLR_in === 1'bx) 
        assign Q_out = 1'bx;
      else
        deassign Q_out;

`ifdef XIL_TIMING
generate
if (IS_C_INVERTED == 1'b0) begin : generate_block1
  always @(posedge C_dly or posedge CLR_in)
    if (CLR_in || (CLR === 1'bx && Q_out == 1'b0))
      Q_out <= 1'b0;
    else if (CE_dly || (CE === 1'bz) || ((CE === 1'bx) && (Q_out == (D_dly ^ IS_D_INVERTED_REG))))
      Q_out <= D_dly ^ IS_D_INVERTED_REG;
end else begin : generate_block1
  always @(negedge C_dly or posedge CLR_in)
    if (CLR_in || (CLR === 1'bx && Q_out == 1'b0))
      Q_out <= 1'b0;
    else if (CE_dly || (CE === 1'bz) || ((CE === 1'bx) && (Q_out == (D_dly ^ IS_D_INVERTED_REG))))
      Q_out <= D_dly ^ IS_D_INVERTED_REG;
end
endgenerate
`else
generate
if (IS_C_INVERTED == 1'b0) begin : generate_block1
  always @(posedge C or posedge CLR_in)
    if (CLR_in || (CLR === 1'bx && Q_out == 1'b0))
      Q_out <= 1'b0;
    else if (CE || (CE === 1'bz) || ((CE === 1'bx) && (Q_out == (D ^ IS_D_INVERTED_REG))))
      Q_out <= D ^ IS_D_INVERTED_REG;
end else begin : generate_block1
  always @(negedge C or posedge CLR_in)
    if (CLR_in || (CLR === 1'bx && Q_out == 1'b0))
      Q_out <= 1'b0;
    else if (CE || (CE === 1'bz) || ((CE === 1'bx) && (Q_out == (D ^ IS_D_INVERTED_REG))))
      Q_out <= D ^ IS_D_INVERTED_REG;
end
endgenerate
`endif

`ifdef XIL_TIMING
    reg notifier;
    wire notifier1;
`endif

`ifdef XIL_TIMING
    wire ngsr, in_out;
    wire nrst;
    wire in_clk_enable, in_clk_enable_p, in_clk_enable_n;
    wire ce_clk_enable, ce_clk_enable_p, ce_clk_enable_n;
    reg init_enable = 1'b1;
    wire rst_clk_enable, rst_clk_enable_p, rst_clk_enable_n;
`endif

`ifdef XIL_TIMING
    not (ngsr, glblGSR);
    xor (in_out, D_dly, IS_D_INVERTED_REG, Q_out);
    not (nrst, (CLR_dly ^ IS_CLR_INVERTED_REG) && (CLR !== 1'bz));

    and (in_clk_enable, ngsr, nrst, CE || (CE === 1'bz));
    and (ce_clk_enable, ngsr, nrst, in_out);
    and (rst_clk_enable, ngsr, CE || (CE === 1'bz), D ^ IS_D_INVERTED_REG);
    always @(negedge nrst) init_enable = (MSGON =="TRUE") && ~glblGSR && (Q_out ^ INIT);

    assign notifier1 = (XON == "FALSE") ?  1'bx : notifier;
    assign ce_clk_enable_n = (MSGON =="TRUE") && ce_clk_enable && (IS_C_INVERTED == 1'b1);
    assign in_clk_enable_n = (MSGON =="TRUE") && in_clk_enable && (IS_C_INVERTED == 1'b1);
    assign rst_clk_enable_n = (MSGON =="TRUE") && rst_clk_enable && (IS_C_INVERTED == 1'b1);
    assign ce_clk_enable_p = (MSGON =="TRUE") && ce_clk_enable && (IS_C_INVERTED == 1'b0);
    assign in_clk_enable_p = (MSGON =="TRUE") && in_clk_enable && (IS_C_INVERTED == 1'b0);
    assign rst_clk_enable_p = (MSGON =="TRUE") && rst_clk_enable && (IS_C_INVERTED == 1'b0);
`endif

// end behavioral model

`ifdef XIL_TIMING
  specify
  (C => Q) = (100:100:100, 100:100:100);
  (negedge CLR => (Q +: 0)) = (0:0:0, 0:0:0);
  (posedge CLR => (Q +: 0)) = (0:0:0, 0:0:0);
  (CLR => Q) = (0:0:0, 0:0:0);
  $period (negedge C &&& CE, 0:0:0, notifier);
  $period (posedge C &&& CE, 0:0:0, notifier);
  $recrem (negedge CLR, negedge C, 0:0:0, 0:0:0, notifier,rst_clk_enable_n,rst_clk_enable_n,CLR_dly, C_dly);
  $recrem (negedge CLR, posedge C, 0:0:0, 0:0:0, notifier,rst_clk_enable_p,rst_clk_enable_p,CLR_dly, C_dly);
  $recrem (posedge CLR, negedge C, 0:0:0, 0:0:0, notifier,rst_clk_enable_n,rst_clk_enable_n,CLR_dly, C_dly);
  $recrem (posedge CLR, posedge C, 0:0:0, 0:0:0, notifier,rst_clk_enable_p,rst_clk_enable_p,CLR_dly, C_dly);
  $setuphold (negedge C, negedge CE, 0:0:0, 0:0:0, notifier,ce_clk_enable_n,ce_clk_enable_n,C_dly,CE_dly);
  $setuphold (negedge C, negedge D, 0:0:0, 0:0:0, notifier,in_clk_enable_n,in_clk_enable_n,C_dly,D_dly);
  $setuphold (negedge C, posedge CE, 0:0:0, 0:0:0, notifier,ce_clk_enable_n,ce_clk_enable_n,C_dly,CE_dly);
  $setuphold (negedge C, posedge D, 0:0:0, 0:0:0, notifier,in_clk_enable_n,in_clk_enable_n,C_dly,D_dly);
  $setuphold (posedge C, negedge CE, 0:0:0, 0:0:0, notifier,ce_clk_enable_p,ce_clk_enable_p,C_dly,CE_dly);
  $setuphold (posedge C, negedge D, 0:0:0, 0:0:0, notifier,in_clk_enable_p,in_clk_enable_p,C_dly,D_dly);
  $setuphold (posedge C, posedge CE, 0:0:0, 0:0:0, notifier,ce_clk_enable_p,ce_clk_enable_p,C_dly,CE_dly);
  $setuphold (posedge C, posedge D, 0:0:0, 0:0:0, notifier,in_clk_enable_p,in_clk_enable_p,C_dly,D_dly);
  $width (negedge C &&& CE, 0:0:0, 0, notifier);
  $width (negedge CLR &&& init_enable, 0:0:0, 0, notifier);
  $width (posedge C &&& CE, 0:0:0, 0, notifier);
  $width (posedge CLR &&& init_enable, 0:0:0, 0, notifier);
  specparam PATHPULSE$ = 0;
  endspecify
`endif
endmodule

`endcelldefine

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2009 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor : Xilinx
// \   \   \/     Version : 10.1
//  \   \         Description : Xilinx Functional Simulation Library Component
//  /   /                  GND Connection
// /___/   /\     Filename : GND.v
// \   \  /  \    Timestamp : Thu Mar 25 16:42:19 PST 2004
//  \___\/\___\
//
// Revision:
//    03/23/04 - Initial version.
//    05/23/07 - Changed timescale to 1 ps / 1 ps.

`timescale  1 ps / 1 ps


`celldefine

module GND(G);


`ifdef XIL_TIMING

    parameter LOC = "UNPLACED";

`endif

    output G;

    assign G = 1'b0;

endmodule

`endcelldefine


///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  2-Bit Look-Up Table
// /___/   /\     Filename : LUT2.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    03/23/04 - Initial version.
//    03/11/05 - Add LOC Parameter
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT2 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [3:0] INIT = 4'h0
)(
  output O,

  input I0,
  input I1
);

// define constants
  localparam MODULE_NAME = "LUT2";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT2_dr.v"
`else
  reg [3:0] INIT_REG = INIT;
`endif

  x_lut2_mux4 (O, INIT_REG[3], INIT_REG[2], INIT_REG[1], INIT_REG[0], I1, I0);

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	(I1 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

primitive x_lut2_mux4 (o, d3, d2, d1, d0, s1, s0);

  output o;
  input d3, d2, d1, d0;
  input s1, s0;

  table

    // d3  d2  d1  d0  s1  s0 : o;

       ?   ?   ?   1   0   0  : 1;
       ?   ?   ?   0   0   0  : 0;
       ?   ?   1   ?   0   1  : 1;
       ?   ?   0   ?   0   1  : 0;
       ?   1   ?   ?   1   0  : 1;
       ?   0   ?   ?   1   0  : 0;
       1   ?   ?   ?   1   1  : 1;
       0   ?   ?   ?   1   1  : 0;

       ?   ?   0   0   0   x  : 0;
       ?   ?   1   1   0   x  : 1;
       0   0   ?   ?   1   x  : 0;
       1   1   ?   ?   1   x  : 1;

       ?   0   ?   0   x   0  : 0;
       ?   1   ?   1   x   0  : 1;
       0   ?   0   ?   x   1  : 0;
       1   ?   1   ?   x   1  : 1;

       0   0   0   0   x   x  : 0;
       1   1   1   1   x   x  : 1;

  endtable

endprimitive

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2009 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor : Xilinx
// \   \   \/     Version : 10.1
//  \   \         Description : Xilinx Functional Simulation Library Component
//  /   /                  VCC Connection
// /___/   /\     Filename : VCC.v
// \   \  /  \    Timestamp : Thu Mar 25 16:43:41 PST 2004
//  \___\/\___\
//
// Revision:
//    03/23/04 - Initial version.
//    05/23/07 - Changed timescale to 1 ps / 1 ps.
//    12/13/11 - Added `celldefine and `endcelldefine (CR 524859).
// End Revision

`timescale  1 ps / 1 ps


`celldefine

module VCC(P);


`ifdef XIL_TIMING

    parameter LOC = "UNPLACED";

`endif


    output P;

    assign P = 1'b1;

endmodule

`endcelldefine


///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  5-Bit Look-Up Table
// /___/   /\     Filename : LUT5.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    03/23/04 - Initial version.
//    02/04/05 - Replace primitive with function; Remove buf.
//    01/07/06 - 222733 - Add LOC Parameter
//    06/04/07 - Add wire declaration to internal signal.
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT5 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [31:0] INIT = 32'h00000000
)(
  output O,

  input I0,
  input I1,
  input I2,
  input I3,
  input I4
);

// define constants
  localparam MODULE_NAME = "LUT5";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT5_dr.v"
`else
  reg [31:0] INIT_REG = INIT;
`endif

// begin behavioral model

  reg O_out;

  assign O = O_out;

  function lut_mux4_f;
  input [3:0] d;
  input [1:0] s;
  begin
    if (((s[1]^s[0]) === 1'b1) || ((s[1]^s[0]) === 1'b0))
      lut_mux4_f = d[s];
    else if ( ~(|d) || &d)
      lut_mux4_f = d[0];
    else if (((s[0] === 1'b1) || (s[0] === 1'b0)) && (d[{1'b0,s[0]}] === d[{1'b1,s[0]}]))
      lut_mux4_f = d[{1'b0,s[0]}];
    else if (((s[1] === 1'b1) || (s[1] === 1'b0)) && (d[{s[1],1'b0}] === d[{s[1],1'b1}]))
      lut_mux4_f = d[{s[1],1'b0}];
    else
      lut_mux4_f = 1'bx;
  end
  endfunction

  function lut_mux8_f;
  input [7:0] d;
  input [2:0] s;
  begin
    if (((s[2]^s[1]^s[0]) === 1'b1) || ((s[2]^s[1]^s[0]) === 1'b0))
      lut_mux8_f = d[s];
    else if ( ~(|d) || &d)
      lut_mux8_f = d[0];
    else if ((((s[1]^s[0]) === 1'b1) || ((s[1]^s[0]) === 1'b0)) &&
             (d[{1'b0,s[1:0]}] === d[{1'b1,s[1:0]}]))
      lut_mux8_f = d[{1'b0,s[1:0]}];
    else if ((((s[2]^s[0]) === 1'b1) || ((s[2]^s[0]) === 1'b0)) &&
             (d[{s[2],1'b0,s[0]}] === d[{s[2],1'b1,s[0]}]))
      lut_mux8_f = d[{s[2],1'b0,s[0]}];
    else if ((((s[2]^s[1]) === 1'b1) || ((s[2]^s[1]) === 1'b0)) &&
             (d[{s[2],s[1],1'b0}] === d[{s[2],s[1],1'b1}]))
      lut_mux8_f = d[{s[2:1],1'b0}];
    else if (((s[0] === 1'b1) || (s[0] === 1'b0)) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b0,1'b1,s[0]}]) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b1,1'b0,s[0]}]) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b1,1'b1,s[0]}]))
      lut_mux8_f = d[{1'b0,1'b0,s[0]}];
    else if (((s[1] === 1'b1) || (s[1] === 1'b0)) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b0,s[1],1'b1}]) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b1,s[1],1'b0}]) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b1,s[1],1'b1}]))
      lut_mux8_f = d[{1'b0,s[1],1'b0}];
    else if (((s[2] === 1'b1) || (s[2] === 1'b0)) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b0,1'b1}]) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b1,1'b0}]) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b1,1'b1}]))
      lut_mux8_f = d[{s[2],1'b0,1'b0}];
    else
      lut_mux8_f = 1'bx;
  end
  endfunction

 always @(I0 or I1 or I2 or I3 or I4)  begin
   if ( (I0 ^ I1  ^ I2 ^ I3 ^ I4) === 1'b0 || (I0 ^ I1  ^ I2 ^ I3 ^ I4) === 1'b1)
     O_out = INIT_REG[{I4, I3, I2, I1, I0}];
   else if ( ~(|INIT_REG) || &INIT_REG )
     O_out = INIT_REG[0];
   else
     O_out = lut_mux4_f ({lut_mux8_f (INIT_REG[31:24], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[23:16], {I2, I1, I0}),
                      lut_mux8_f ( INIT_REG[15:8], {I2, I1, I0}),
                      lut_mux8_f (  INIT_REG[7:0], {I2, I1, I0})}, {I4, I3});
  end

// end behavioral model

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	(I1 => O) = (0:0:0, 0:0:0);
	(I2 => O) = (0:0:0, 0:0:0);
	(I3 => O) = (0:0:0, 0:0:0);
	(I4 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995/2016 Xilinx, Inc.
// All Right Reserved.
///////////////////////////////////////////////////////////////////////////////
//   ____  ____
//  /   /\/   /
// /___/  \  /    Vendor      : Xilinx
// \   \   \/     Version     : 2017.1
//  \   \         Description : Xilinx Unified Simulation Library Component
//  /   /                  6-Bit Look-Up Table
// /___/   /\     Filename : LUT6.v
// \   \  /  \
//  \___\/\___\
//
///////////////////////////////////////////////////////////////////////////////
//  Revision:
//    03/23/04 - Initial version.
//    02/04/05 - Replace primitive with function; Remove buf.
//    01/07/06 - 222733 - Add LOC Parameter
//    06/04/07 - Add wire declaration to internal signal.
//    12/13/11 - 524859 - Added `celldefine and `endcelldefine
//    09/12/16 - ANSI ports, speed improvements
//  End Revision:
///////////////////////////////////////////////////////////////////////////////

`timescale 1 ps/1 ps

`celldefine

module LUT6 #(
`ifdef XIL_TIMING
  parameter LOC = "UNPLACED",
`endif
  parameter [63:0] INIT = 64'h0000000000000000
)(
  output O,

  input I0,
  input I1,
  input I2,
  input I3,
  input I4,
  input I5
);

// define constants
  localparam MODULE_NAME = "LUT6";

  reg trig_attr = 1'b0;
// include dynamic registers - XILINX test only
`ifdef XIL_DR
  `include "LUT6_dr.v"
`else
  reg [63:0] INIT_REG = INIT;
`endif

// begin behavioral model

  reg O_out;

  assign O = O_out;

  function lut_mux8_f;
  input [7:0] d;
  input [2:0] s;
  begin
    if (((s[2]^s[1]^s[0]) === 1'b1) || ((s[2]^s[1]^s[0]) === 1'b0))
      lut_mux8_f = d[s];
    else if ( ~(|d) || &d)
      lut_mux8_f = d[0];
    else if ((((s[1]^s[0]) === 1'b1) || ((s[1]^s[0]) === 1'b0)) &&
             (d[{1'b0,s[1:0]}] === d[{1'b1,s[1:0]}]))
      lut_mux8_f = d[{1'b0,s[1:0]}];
    else if ((((s[2]^s[0]) === 1'b1) || ((s[2]^s[0]) === 1'b0)) &&
             (d[{s[2],1'b0,s[0]}] === d[{s[2],1'b1,s[0]}]))
      lut_mux8_f = d[{s[2],1'b0,s[0]}];
    else if ((((s[2]^s[1]) === 1'b1) || ((s[2]^s[1]) === 1'b0)) &&
             (d[{s[2],s[1],1'b0}] === d[{s[2],s[1],1'b1}]))
      lut_mux8_f = d[{s[2:1],1'b0}];
    else if (((s[0] === 1'b1) || (s[0] === 1'b0)) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b0,1'b1,s[0]}]) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b1,1'b0,s[0]}]) &&
             (d[{1'b0,1'b0,s[0]}] === d[{1'b1,1'b1,s[0]}]))
      lut_mux8_f = d[{1'b0,1'b0,s[0]}];
    else if (((s[1] === 1'b1) || (s[1] === 1'b0)) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b0,s[1],1'b1}]) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b1,s[1],1'b0}]) &&
             (d[{1'b0,s[1],1'b0}] === d[{1'b1,s[1],1'b1}]))
      lut_mux8_f = d[{1'b0,s[1],1'b0}];
    else if (((s[2] === 1'b1) || (s[2] === 1'b0)) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b0,1'b1}]) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b1,1'b0}]) &&
             (d[{s[2],1'b0,1'b0}] === d[{s[2],1'b1,1'b1}]))
      lut_mux8_f = d[{s[2],1'b0,1'b0}];
    else
      lut_mux8_f = 1'bx;
  end
  endfunction

 always @(I0 or I1 or I2 or I3 or I4 or I5)  begin
   if ( (I0 ^ I1  ^ I2 ^ I3 ^ I4 ^ I5) === 1'b0 || (I0 ^ I1  ^ I2 ^ I3 ^ I4 ^ I5) === 1'b1)
     O_out = INIT_REG[{I5, I4, I3, I2, I1, I0}];
   else if ( ~(|INIT_REG) || &INIT_REG )
     O_out = INIT_REG[0];
   else
     O_out = lut_mux8_f ({lut_mux8_f (INIT_REG[63:56], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[55:48], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[47:40], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[39:32], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[31:24], {I2, I1, I0}),
                      lut_mux8_f (INIT_REG[23:16], {I2, I1, I0}),
                      lut_mux8_f ( INIT_REG[15:8], {I2, I1, I0}),
                      lut_mux8_f (  INIT_REG[7:0], {I2, I1, I0})}, {I5, I4, I3});
 end

// end behavioral model

`ifdef XIL_TIMING
  specify
	(I0 => O) = (0:0:0, 0:0:0);
	(I1 => O) = (0:0:0, 0:0:0);
	(I2 => O) = (0:0:0, 0:0:0);
	(I3 => O) = (0:0:0, 0:0:0);
	(I4 => O) = (0:0:0, 0:0:0);
	(I5 => O) = (0:0:0, 0:0:0);
	specparam PATHPULSE$ = 0;
  endspecify
`endif

endmodule

`endcelldefine

`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
